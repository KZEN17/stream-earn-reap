import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Home from './pages/Home'
import LaunchCalendar from './pages/LaunchCalendar'
import Rewards from './pages/Rewards'
import RaidChat from './pages/RaidChat'
import Leaderboards from './pages/Leaderboards'
import Guide from './pages/Guide'
import Profile from './pages/Profile'
import BrandBook from './pages/BrandBook'
import UIKit from './pages/UIKit'
import MediaPack from './pages/MediaPack'
import ThemeShowcase from './components/demo/ThemeShowcase'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/calendar" element={<LaunchCalendar />} />
        <Route path="/rewards" element={<Rewards />} />
        <Route path="/raidchat" element={<RaidChat />} />
        <Route path="/leaderboards" element={<Leaderboards />} />
        <Route path="/guide" element={<Guide />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/brand-book" element={<BrandBook />} />
        <Route path="/ui-kit" element={<UIKit />} />
        <Route path="/media-pack" element={<MediaPack />} />
        <Route path="/theme-showcase" element={<ThemeShowcase />} />
      </Routes>
    </Layout>
  )
}

export default App
