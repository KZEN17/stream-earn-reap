import React from 'react'
import { motion } from 'framer-motion'
import { Calendar, Clock, Users, Star } from 'lucide-react'

const LaunchCalendar: React.FC = () => {
  const events = [
    {
      id: 1,
      title: 'Gaming Tournament Finals',
      date: '2024-01-15',
      time: '8:00 PM EST',
      participants: 156,
      category: 'Gaming',
      featured: true
    },
    {
      id: 2,
      title: 'Music Production Workshop',
      date: '2024-01-16',
      time: '3:00 PM EST',
      participants: 89,
      category: 'Music',
      featured: false
    },
    {
      id: 3,
      title: 'Cooking Challenge',
      date: '2024-01-17',
      time: '6:00 PM EST',
      participants: 234,
      category: 'Cooking',
      featured: true
    }
  ]

  return (
    <div className="p-4 lg:p-8 space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 
          className="text-4xl font-bold mb-4"
          style={{ 
            fontFamily: 'Space Grotesk, sans-serif',
            color: '#3CFF88',
            textShadow: '0 0 10px rgba(60, 255, 136, 0.5)'
          }}
        >
          Launch Calendar
        </h1>
        <p className="text-xl" style={{ color: '#D1D5DB' }}>
          Upcoming events and stream launches
        </p>
      </motion.div>

      <div className="grid gap-6">
        {events.map((event, index) => (
          <motion.div
            key={event.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-6 rounded-lg transition-all duration-300 cursor-pointer"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.05)',
              backdropFilter: 'blur(12px)',
              border: '1px solid rgba(255, 255, 255, 0.1)'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.05)'
            }}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div 
                  className="p-3 rounded-lg"
                  style={{ backgroundColor: 'rgba(60, 255, 136, 0.2)' }}
                >
                  <Calendar className="w-6 h-6" style={{ color: '#3CFF88' }} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-1">{event.title}</h3>
                  <span 
                    className="px-3 py-1 rounded-full text-sm font-medium"
                    style={{ 
                      backgroundColor: 'rgba(0, 224, 255, 0.2)',
                      color: '#00E0FF'
                    }}
                  >
                    {event.category}
                  </span>
                </div>
              </div>
              
              {event.featured && (
                <div className="flex items-center gap-1 text-yellow-400">
                  <Star className="w-4 h-4 fill-current" />
                  <span className="text-sm font-medium">Featured</span>
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-6 text-sm" style={{ color: '#9CA3AF' }}>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>{event.date} at {event.time}</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                <span>{event.participants} participants</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

export default LaunchCalendar
