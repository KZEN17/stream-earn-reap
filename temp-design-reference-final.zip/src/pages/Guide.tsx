import React from 'react'
import { motion } from 'framer-motion'
import { BookOpen, Play, Scissors, DollarSign } from 'lucide-react'

const Guide: React.FC = () => {
  const steps = [
    {
      id: 1,
      icon: Play,
      title: 'Start Streaming',
      description: 'Begin your live stream on your favorite platform and connect it to ClipStream.',
      color: '#3CFF88'
    },
    {
      id: 2,
      icon: Scissors,
      title: 'Create Clips',
      description: 'Use our tools to create engaging clips from your stream highlights.',
      color: '#00E0FF'
    },
    {
      id: 3,
      icon: DollarSign,
      title: 'Earn Rewards',
      description: 'Get paid based on views, engagement, and viral potential of your clips.',
      color: '#FF1B8D'
    }
  ]

  return (
    <div className="p-4 lg:p-8 space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 
          className="text-4xl font-bold mb-4"
          style={{ 
            fontFamily: 'Space Grotesk, sans-serif',
            color: '#3CFF88',
            textShadow: '0 0 10px rgba(60, 255, 136, 0.5)'
          }}
        >
          Getting Started Guide
        </h1>
        <p className="text-xl" style={{ color: '#D1D5DB' }}>
          Learn how to maximize your earnings on ClipStream
        </p>
      </motion.div>

      <div className="grid gap-8">
        {steps.map((step, index) => {
          const Icon = step.icon
          return (
            <motion.div
              key={step.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2 }}
              className="p-6 rounded-lg transition-all duration-300"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.05)',
                backdropFilter: 'blur(12px)',
                border: '1px solid rgba(255, 255, 255, 0.1)'
              }}
            >
              <div className="flex items-start gap-6">
                <div 
                  className="w-16 h-16 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: `${step.color}20` }}
                >
                  <Icon className="w-8 h-8" style={{ color: step.color }} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-3" style={{ color: step.color }}>
                    Step {step.id}: {step.title}
                  </h3>
                  <p className="text-lg leading-relaxed" style={{ color: '#D1D5DB' }}>
                    {step.description}
                  </p>
                </div>
              </div>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}

export default Guide
