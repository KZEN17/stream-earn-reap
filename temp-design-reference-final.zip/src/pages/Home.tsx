import React from 'react'
import { motion } from 'framer-motion'
import MetricCard from '../components/MetricCard'
import FeatureCard from '../components/FeatureCard'
import TrendingStreams from '../components/TrendingStreams'
import RecentClips from '../components/RecentClips'
import { 
  DollarSign, 
  Users, 
  Video, 
  Eye, 
  TrendingUp, 
  Repeat, 
  Banknote,
  Play,
  Scissors
} from 'lucide-react'

const Home: React.FC = () => {
  const metrics = [
    {
      title: 'Total Rewards Paid',
      value: '$125,340',
      change: '+12.5%',
      icon: DollarSign,
      color: 'neon-green'
    },
    {
      title: 'Active Creators',
      value: '3,456',
      change: '+8.2%',
      icon: Users,
      color: 'neon-cyan'
    },
    {
      title: 'Clips Created',
      value: '45,678',
      change: '+15.3%',
      icon: Video,
      color: 'neon-magenta'
    },
    {
      title: 'Total Views',
      value: '2.1M',
      change: '+23.1%',
      icon: Eye,
      color: 'neon-green'
    }
  ]

  const features = [
    {
      icon: TrendingUp,
      title: 'Stream & Earn',
      description: 'Create viral clips from live streams and earn rewards based on views and engagement.',
      color: 'neon-green'
    },
    {
      icon: Repeat,
      title: 'Loop Rewards & Grow',
      description: 'Recycle hype, multiply rewards. Every fee compounds into more reach and value.',
      color: 'neon-cyan'
    },
    {
      icon: Banknote,
      title: 'Entertainment Finance',
      description: 'Turn entertainment into sustainable income as an innovative creator.',
      color: 'neon-magenta'
    }
  ]

  const buttonStyle = {
    backgroundColor: '#212529',
    border: '1px solid rgba(60, 255, 136, 0.5)',
    color: '#3CFF88',
    padding: '16px 32px',
    borderRadius: '8px',
    fontWeight: '500',
    transition: 'all 0.3s ease',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    fontSize: '18px'
  }

  const secondaryButtonStyle = {
    ...buttonStyle,
    borderColor: 'rgba(0, 224, 255, 0.5)',
    color: '#00E0FF'
  }

  return (
    <div className="p-4 lg:p-8 space-y-8">
      {/* Hero Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center py-12 lg:py-20"
      >
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="font-bold text-4xl lg:text-6xl mb-6"
          style={{ fontFamily: 'Space Grotesk, sans-serif' }}
        >
          <span 
            style={{
              background: 'linear-gradient(135deg, #3CFF88, #00E0FF, #FF1B8D)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text'
            }}
          >
            STREAM • CLIP • EARN $
          </span>
        </motion.h1>
        
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-xl lg:text-2xl mb-8 max-w-3xl mx-auto"
          style={{ color: '#D1D5DB' }}
        >
          Create viral clips from live streams and earn rewards based on views and engagement. 
          The future of entertainment finance.
        </motion.p>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center"
        >
          <button 
            style={buttonStyle}
            onMouseEnter={(e) => {
              e.target.style.backgroundColor = 'rgba(60, 255, 136, 0.1)'
              e.target.style.borderColor = '#3CFF88'
              e.target.style.boxShadow = '0 0 10px rgba(60, 255, 136, 0.3)'
            }}
            onMouseLeave={(e) => {
              e.target.style.backgroundColor = '#212529'
              e.target.style.borderColor = 'rgba(60, 255, 136, 0.5)'
              e.target.style.boxShadow = 'none'
            }}
          >
            <Scissors className="w-5 h-5" />
            START CLIPPING
          </button>
          <button 
            style={secondaryButtonStyle}
            onMouseEnter={(e) => {
              e.target.style.backgroundColor = 'rgba(0, 224, 255, 0.1)'
              e.target.style.borderColor = '#00E0FF'
              e.target.style.boxShadow = '0 0 10px rgba(0, 224, 255, 0.3)'
            }}
            onMouseLeave={(e) => {
              e.target.style.backgroundColor = '#212529'
              e.target.style.borderColor = 'rgba(0, 224, 255, 0.5)'
              e.target.style.boxShadow = 'none'
            }}
          >
            <Play className="w-5 h-5" />
            START STREAMING
          </button>
        </motion.div>
      </motion.section>

      {/* Metrics */}
      <section>
        <motion.h2
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="font-bold text-2xl lg:text-3xl mb-6"
          style={{ 
            fontFamily: 'Space Grotesk, sans-serif',
            color: '#3CFF88',
            textShadow: '0 0 10px rgba(60, 255, 136, 0.5)'
          }}
        >
          Platform Growth
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
          style={{ color: '#9CA3AF' }}
        >
          Real numbers from our thriving creator economy
        </motion.p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {metrics.map((metric, index) => (
            <motion.div
              key={metric.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <MetricCard {...metric} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.1 }}
            >
              <FeatureCard {...feature} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* Content Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
        >
          <TrendingStreams />
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <RecentClips />
        </motion.div>
      </div>
    </div>
  )
}

export default Home
