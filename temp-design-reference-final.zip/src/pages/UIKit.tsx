import React, { useState } from 'react'
import { Play, Pause, Settings, User, Heart, Share2, Download } from 'lucide-react'
import Button from '../components/ui/Button'
import Card from '../components/ui/Card'
import Input from '../components/ui/Input'
import Toggle from '../components/ui/Toggle'
import Progress from '../components/ui/Progress'
import Avatar from '../components/ui/Avatar'
import Modal from '../components/ui/Modal'
import Dropdown from '../components/ui/Dropdown'
import Slider from '../components/ui/Slider'
import Checkbox from '../components/ui/Checkbox'
import LoadingSpinner from '../components/ui/LoadingSpinner'
import Table from '../components/ui/Table'

const UIKit: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [toggleValue, setToggleValue] = useState(false)
  const [sliderValue, setSliderValue] = useState(50)
  const [checkboxValue, setCheckboxValue] = useState(false)
  const [dropdownValue, setDropdownValue] = useState('')

  const dropdownOptions = [
    { value: 'option1', label: 'Option 1', icon: <User size={16} /> },
    { value: 'option2', label: 'Option 2', icon: <Settings size={16} /> },
    { value: 'option3', label: 'Option 3', icon: <Heart size={16} /> }
  ]

  const tableColumns = [
    { key: 'rank', label: 'Rank' },
    { key: 'user', label: 'User', render: (value: any) => (
      <div className="flex items-center gap-3">
        <Avatar size="sm" fallback={value.charAt(0)} />
        <span>{value}</span>
      </div>
    )},
    { key: 'earnings', label: 'Earnings', render: (value: number) => (
      <span className="text-neon-green font-semibold">${value.toLocaleString()}</span>
    )},
    { key: 'clips', label: 'Clips' }
  ]

  const tableData = [
    { rank: 1, user: 'StreamerPro', earnings: 15420, clips: 342 },
    { rank: 2, user: 'ClipMaster', earnings: 12890, clips: 298 },
    { rank: 3, user: 'EarningsKing', earnings: 9750, clips: 256 }
  ]

  return (
    <div className="min-h-screen bg-dark-950 text-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-neon-cyan/20 via-neon-purple/20 to-neon-magenta/20 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-5xl font-bold mb-4">
                <span className="text-gradient">UI Kit</span> Components
              </h1>
              <p className="text-xl text-gray-300">Complete component library for CLIP platform</p>
            </div>
            <button className="btn-primary flex items-center gap-2">
              <Download size={20} />
              Export Components
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-12 space-y-16">
        {/* Buttons */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-green">Buttons</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="glass-panel p-6">
              <h3 className="font-semibold mb-4">Primary</h3>
              <div className="space-y-3">
                <Button variant="primary">Primary Button</Button>
                <Button variant="primary" size="sm">Small</Button>
                <Button variant="primary" size="lg">Large</Button>
                <Button variant="primary" disabled>Disabled</Button>
                <Button variant="primary" isLoading>Loading</Button>
              </div>
            </div>

            <div className="glass-panel p-6">
              <h3 className="font-semibold mb-4">Secondary</h3>
              <div className="space-y-3">
                <Button variant="secondary">Secondary Button</Button>
                <Button variant="secondary" size="sm">Small</Button>
                <Button variant="secondary" size="lg">Large</Button>
                <Button variant="secondary" disabled>Disabled</Button>
              </div>
            </div>

            <div className="glass-panel p-6">
              <h3 className="font-semibold mb-4">Tertiary</h3>
              <div className="space-y-3">
                <Button variant="tertiary">Tertiary Button</Button>
                <Button variant="tertiary" size="sm">Small</Button>
                <Button variant="tertiary" size="lg">Large</Button>
                <Button variant="tertiary" disabled>Disabled</Button>
              </div>
            </div>

            <div className="glass-panel p-6">
              <h3 className="font-semibold mb-4">Ghost</h3>
              <div className="space-y-3">
                <Button variant="ghost">Ghost Button</Button>
                <Button variant="ghost" size="sm">Small</Button>
                <Button variant="ghost" size="lg">Large</Button>
                <Button variant="ghost" disabled>Disabled</Button>
              </div>
            </div>
          </div>
        </section>

        {/* Cards */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-cyan">Cards</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card variant="default">
              <h3 className="font-semibold mb-2">Default Card</h3>
              <p className="text-gray-400 text-sm">Basic card component with glass morphism effect and hover states.</p>
            </Card>

            <Card variant="campaign">
              <h3 className="font-semibold mb-2 text-neon-green">Campaign Card</h3>
              <p className="text-gray-400 text-sm">Featured campaign card with accent border and special styling.</p>
            </Card>

            <Card variant="profile">
              <div className="flex items-center gap-3 mb-3">
                <Avatar size="md" fallback="U" />
                <div>
                  <h3 className="font-semibold">Profile Card</h3>
                  <p className="text-sm text-gray-400">@username</p>
                </div>
              </div>
              <p className="text-gray-400 text-sm">User profile card with avatar and hover effects.</p>
            </Card>
          </div>
        </section>

        {/* Form Elements */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-purple">Form Elements</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass-panel p-6 space-y-6">
              <h3 className="font-semibold mb-4">Inputs & Controls</h3>
              
              <Input
                label="Username"
                placeholder="Enter your username"
                icon={<User size={16} />}
              />
              
              <Input
                label="Email"
                type="email"
                placeholder="Enter your email"
                error="Please enter a valid email"
              />

              <Dropdown
                label="Select Platform"
                options={dropdownOptions}
                value={dropdownValue}
                onChange={setDropdownValue}
                placeholder="Choose a platform"
              />

              <Toggle
                checked={toggleValue}
                onChange={setToggleValue}
                label="Enable notifications"
              />

              <Checkbox
                checked={checkboxValue}
                onChange={setCheckboxValue}
                label="I agree to the terms and conditions"
              />
            </div>

            <div className="glass-panel p-6 space-y-6">
              <h3 className="font-semibold mb-4">Sliders & Progress</h3>
              
              <Slider
                label="Volume"
                value={sliderValue}
                onChange={setSliderValue}
                showValue
              />

              <Progress
                label="Campaign Progress"
                value={75}
                showLabel
              />

              <Progress
                variant="circular"
                value={65}
                showLabel
                size="lg"
              />

              <div className="flex items-center gap-4">
                <LoadingSpinner size="sm" />
                <LoadingSpinner size="md" />
                <LoadingSpinner size="lg" />
                <LoadingSpinner variant="secondary" />
              </div>
            </div>
          </div>
        </section>

        {/* Avatars */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-yellow">Avatars</h2>
          <div className="glass-panel p-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="text-center">
                <Avatar size="sm" fallback="S" className="mb-2 mx-auto" />
                <p className="text-sm text-gray-400">Small</p>
              </div>
              <div className="text-center">
                <Avatar size="md" fallback="M" className="mb-2 mx-auto" />
                <p className="text-sm text-gray-400">Medium</p>
              </div>
              <div className="text-center">
                <Avatar size="lg" fallback="L" className="mb-2 mx-auto" />
                <p className="text-sm text-gray-400">Large</p>
              </div>
              <div className="text-center">
                <Avatar size="xl" fallback="XL" className="mb-2 mx-auto" />
                <p className="text-sm text-gray-400">Extra Large</p>
              </div>
            </div>
            
            <div className="mt-8 flex justify-center gap-8">
              <div className="text-center">
                <Avatar size="lg" fallback="L" isLive className="mb-2 mx-auto" />
                <p className="text-sm text-gray-400">Live Indicator</p>
              </div>
            </div>
          </div>
        </section>

        {/* Navigation */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-magenta">Navigation</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Sidebar Navigation */}
            <div className="glass-panel p-6">
              <h3 className="font-semibold mb-4">Sidebar Navigation</h3>
              <nav className="space-y-2">
                <a href="#" className="nav-link active">
                  <Play size={20} />
                  <span>Dashboard</span>
                </a>
                <a href="#" className="nav-link">
                  <Settings size={20} />
                  <span>Settings</span>
                </a>
                <a href="#" className="nav-link">
                  <User size={20} />
                  <span>Profile</span>
                </a>
              </nav>
            </div>

            {/* Bottom Navigation */}
            <div className="glass-panel p-6">
              <h3 className="font-semibold mb-4">Bottom Navigation</h3>
              <div className="flex justify-around bg-dark-800 rounded-lg p-4">
                <button className="flex flex-col items-center gap-1 text-neon-green">
                  <Play size={20} />
                  <span className="text-xs">Home</span>
                </button>
                <button className="flex flex-col items-center gap-1 text-gray-400">
                  <Heart size={20} />
                  <span className="text-xs">Favorites</span>
                </button>
                <button className="flex flex-col items-center gap-1 text-gray-400">
                  <Share2 size={20} />
                  <span className="text-xs">Share</span>
                </button>
                <button className="flex flex-col items-center gap-1 text-gray-400">
                  <User size={20} />
                  <span className="text-xs">Profile</span>
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Tables */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-cyan">Tables</h2>
          <Table
            columns={tableColumns}
            data={tableData}
            zebra
          />
        </section>

        {/* Floating Action Button */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-green">Floating Action Button</h2>
          <div className="glass-panel p-8 text-center">
            <div className="relative inline-block">
              <button className="w-16 h-16 bg-gradient-to-r from-neon-magenta to-neon-purple rounded-full flex items-center justify-center text-white shadow-neon-magenta hover:shadow-neon-lg transition-all duration-300 hover:scale-110">
                <Play size={24} />
              </button>
            </div>
            <p className="text-sm text-gray-400 mt-4">Floating Action Button with gradient and glow effects</p>
          </div>
        </section>

        {/* Modal */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-purple">Modal</h2>
          <div className="glass-panel p-8 text-center">
            <Button onClick={() => setIsModalOpen(true)}>Open Modal</Button>
            
            <Modal
              isOpen={isModalOpen}
              onClose={() => setIsModalOpen(false)}
              title="Create Campaign"
            >
              <div className="space-y-4">
                <Input label="Campaign Name" placeholder="Enter campaign name" />
                <Input label="Description" placeholder="Enter description" />
                <div className="flex gap-3 justify-end">
                  <Button variant="ghost" onClick={() => setIsModalOpen(false)}>
                    Cancel
                  </Button>
                  <Button variant="primary">
                    Create Campaign
                  </Button>
                </div>
              </div>
            </Modal>
          </div>
        </section>
      </div>
    </div>
  )
}

export default UIKit
