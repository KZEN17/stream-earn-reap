import React from 'react'
import { motion } from 'framer-motion'
import { MessageSquare, Users, Send } from 'lucide-react'

const RaidChat: React.FC = () => {
  const messages = [
    { id: 1, user: 'ProGamer123', message: 'Amazing stream today!', time: '2:30 PM' },
    { id: 2, user: 'MusicLover', message: 'That beat drop was insane 🔥', time: '2:31 PM' },
    { id: 3, user: 'ClipMaster', message: 'Just made a clip of that moment', time: '2:32 PM' },
  ]

  return (
    <div className="p-4 lg:p-8 space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 
          className="text-4xl font-bold mb-4"
          style={{ 
            fontFamily: 'Space Grotesk, sans-serif',
            color: '#3CFF88',
            textShadow: '0 0 10px rgba(60, 255, 136, 0.5)'
          }}
        >
          Raid Chat
        </h1>
        <p className="text-xl" style={{ color: '#D1D5DB' }}>
          Connect with the community
        </p>
      </motion.div>

      <div 
        className="rounded-lg p-6 h-96 overflow-y-auto space-y-4"
        style={{
          backgroundColor: 'rgba(255, 255, 255, 0.05)',
          backdropFilter: 'blur(12px)',
          border: '1px solid rgba(255, 255, 255, 0.1)'
        }}
      >
        {messages.map((msg, index) => (
          <motion.div
            key={msg.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-start gap-3"
          >
            <div 
              className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
              style={{ backgroundColor: '#3CFF88', color: '#000' }}
            >
              {msg.user[0]}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-medium text-white">{msg.user}</span>
                <span className="text-xs" style={{ color: '#6B7280' }}>{msg.time}</span>
              </div>
              <p style={{ color: '#D1D5DB' }}>{msg.message}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="flex gap-3">
        <input
          type="text"
          placeholder="Type your message..."
          className="flex-1 px-4 py-3 rounded-lg bg-transparent border text-white placeholder-gray-400 outline-none focus:border-neon-green transition-colors"
          style={{ 
            backgroundColor: 'rgba(255, 255, 255, 0.05)',
            borderColor: 'rgba(255, 255, 255, 0.1)'
          }}
        />
        <button 
          className="px-6 py-3 rounded-lg font-medium transition-all duration-300"
          style={{
            backgroundColor: '#3CFF88',
            color: '#000'
          }}
        >
          <Send className="w-5 h-5" />
        </button>
      </div>
    </div>
  )
}

export default RaidChat
