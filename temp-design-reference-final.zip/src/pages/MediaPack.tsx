import React from 'react'
import { Download, ExternalLink } from 'lucide-react'
import Logo from '../components/branding/Logo'
import SocialBanners from '../components/branding/SocialBanners'

const MediaPack: React.FC = () => {
  const mockupScreens = [
    {
      title: 'Dashboard',
      description: 'Main dashboard with earnings overview',
      image: '/api/placeholder/400/300'
    },
    {
      title: 'Campaign Creation',
      description: 'Create and manage campaigns',
      image: '/api/placeholder/400/300'
    },
    {
      title: 'Leaderboards',
      description: 'Top earners and performers',
      image: '/api/placeholder/400/300'
    },
    {
      title: 'Profile',
      description: 'User profile and settings',
      image: '/api/placeholder/400/300'
    }
  ]

  const presentationSlides = [
    {
      title: 'Title Slide',
      description: 'Main presentation opener',
      gradient: 'from-neon-magenta/30 via-neon-purple/30 to-neon-cyan/30'
    },
    {
      title: 'Section Divider',
      description: 'Chapter/section breaks',
      gradient: 'from-neon-green/30 to-neon-cyan/30'
    },
    {
      title: 'Content Slide',
      description: 'Standard content layout',
      gradient: 'from-neon-purple/20 to-neon-magenta/20'
    }
  ]

  return (
    <div className="min-h-screen bg-dark-950 text-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-neon-green/20 via-neon-cyan/20 to-neon-purple/20 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-5xl font-bold mb-4">
                <span className="text-gradient">Media Pack</span>
              </h1>
              <p className="text-xl text-gray-300">Complete asset library for marketing and presentations</p>
            </div>
            <button className="btn-primary flex items-center gap-2">
              <Download size={20} />
              Download All Assets
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-12 space-y-16">
        {/* Logo Variations */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-green">Logo Variations</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="glass-panel p-8 text-center">
              <div className="mb-6">
                <Logo size="lg" />
              </div>
              <h3 className="font-semibold mb-2">Primary Logo</h3>
              <p className="text-sm text-gray-400 mb-4">Full wordmark with icon</p>
              <button className="btn-secondary text-xs px-3 py-2">
                <Download size={14} className="mr-1" />
                Download
              </button>
            </div>

            <div className="glass-panel p-8 text-center">
              <div className="mb-6 flex justify-center">
                <Logo variant="icon" size="lg" />
              </div>
              <h3 className="font-semibold mb-2">Icon Only</h3>
              <p className="text-sm text-gray-400 mb-4">For small spaces</p>
              <button className="btn-secondary text-xs px-3 py-2">
                <Download size={14} className="mr-1" />
                Download
              </button>
            </div>

            <div className="glass-panel p-8 text-center">
              <div className="mb-6">
                <Logo variant="monochrome" size="lg" />
              </div>
              <h3 className="font-semibold mb-2">Monochrome</h3>
              <p className="text-sm text-gray-400 mb-4">Single color version</p>
              <button className="btn-secondary text-xs px-3 py-2">
                <Download size={14} className="mr-1" />
                Download
              </button>
            </div>

            <div className="glass-panel p-8 text-center">
              <div className="mb-6 flex justify-center">
                <Logo variant="icon" size="md" />
              </div>
              <h3 className="font-semibold mb-2">Favicon</h3>
              <p className="text-sm text-gray-400 mb-4">16x16 / 32x32 px</p>
              <button className="btn-secondary text-xs px-3 py-2">
                <Download size={14} className="mr-1" />
                Download
              </button>
            </div>
          </div>
        </section>

        {/* Social Media Banners */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-cyan">Social Media Banners</h2>
          <SocialBanners />
        </section>

        {/* App Mockups */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-purple">App Mockups</h2>
          
          {/* Desktop Mockups */}
          <div className="mb-12">
            <h3 className="text-xl font-semibold mb-6">Desktop Screens</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {mockupScreens.map((screen, index) => (
                <div key={index} className="glass-panel p-6">
                  <div className="bg-dark-800 rounded-lg p-4 mb-4">
                    {/* Browser Frame */}
                    <div className="flex items-center gap-2 mb-3 pb-3 border-b border-white/10">
                      <div className="flex gap-1">
                        <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                        <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      </div>
                      <div className="flex-1 bg-dark-700 rounded px-3 py-1 text-xs text-gray-400">
                        clip.platform/{screen.title.toLowerCase()}
                      </div>
                    </div>
                    
                    {/* Screen Content */}
                    <div className="aspect-[16/10] bg-gradient-to-br from-neon-magenta/10 to-neon-cyan/10 rounded flex items-center justify-center border border-white/5">
                      <div className="text-center">
                        <Logo size="md" className="mb-3" />
                        <h4 className="font-semibold text-lg">{screen.title}</h4>
                        <p className="text-sm text-gray-400">{screen.description}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold">{screen.title} Screen</h4>
                      <p className="text-sm text-gray-400">{screen.description}</p>
                    </div>
                    <button className="btn-secondary text-xs px-3 py-2">
                      <Download size={14} className="mr-1" />
                      Download
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Mobile Mockups */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Mobile Screens</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {mockupScreens.map((screen, index) => (
                <div key={index} className="glass-panel p-4">
                  <div className="bg-dark-800 rounded-2xl p-3 mb-4">
                    {/* Phone Frame */}
                    <div className="bg-black rounded-xl p-1">
                      <div className="aspect-[9/16] bg-gradient-to-br from-neon-magenta/10 to-neon-cyan/10 rounded-lg flex items-center justify-center">
                        <div className="text-center">
                          <Logo variant="icon" size="sm" className="mb-2" />
                          <h5 className="font-semibold text-sm">{screen.title}</h5>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <h4 className="font-semibold text-sm mb-1">{screen.title}</h4>
                    <button className="btn-secondary text-xs px-2 py-1">
                      <Download size={12} className="mr-1" />
                      Download
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Presentation Templates */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-yellow">Presentation Templates</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {presentationSlides.map((slide, index) => (
              <div key={index} className="glass-panel p-6">
                <div className={`aspect-[16/9] bg-gradient-to-br ${slide.gradient} rounded-lg flex items-center justify-center border border-white/10 mb-4`}>
                  <div className="text-center">
                    {index === 0 && (
                      <>
                        <Logo size="lg" className="mb-4" />
                        <h3 className="text-2xl font-bold mb-2">CLIP Platform</h3>
                        <p className="text-gray-300">Stream • Clip • Earn $</p>
                      </>
                    )}
                    {index === 1 && (
                      <div className="text-center">
                        <div className="w-16 h-1 bg-gradient-to-r from-neon-green to-neon-cyan rounded mb-4 mx-auto"></div>
                        <h3 className="text-3xl font-bold text-gradient">Section Title</h3>
                      </div>
                    )}
                    {index === 2 && (
                      <div className="text-left max-w-sm">
                        <h3 className="text-xl font-bold mb-4 text-neon-cyan">Content Slide</h3>
                        <div className="space-y-2 text-sm text-gray-300">
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 bg-neon-green rounded-full"></div>
                            <span>Bullet point one</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 bg-neon-cyan rounded-full"></div>
                            <span>Bullet point two</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 bg-neon-magenta rounded-full"></div>
                            <span>Bullet point three</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold">{slide.title}</h4>
                    <p className="text-sm text-gray-400">{slide.description}</p>
                  </div>
                  <button className="btn-secondary text-xs px-3 py-2">
                    <Download size={14} className="mr-1" />
                    Download
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Brand Guidelines Quick Reference */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-magenta">Quick Reference</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass-panel p-6">
              <h3 className="font-semibold mb-4">Usage Guidelines</h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-neon-green rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium">Logo Spacing</p>
                    <p className="text-gray-400">Maintain minimum clear space equal to the height of the icon</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-neon-cyan rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium">Color Usage</p>
                    <p className="text-gray-400">Use neon colors sparingly for accents and highlights</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-neon-magenta rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium">Typography</p>
                    <p className="text-gray-400">Space Grotesk for headings, Inter for body text</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="glass-panel p-6">
              <h3 className="font-semibold mb-4">File Formats</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between items-center">
                  <span>Logo Files</span>
                  <span className="text-gray-400">SVG, PNG, PDF</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Social Banners</span>
                  <span className="text-gray-400">PNG, JPG</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>App Mockups</span>
                  <span className="text-gray-400">PNG, PSD</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Presentations</span>
                  <span className="text-gray-400">PPTX, KEY</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

export default MediaPack
