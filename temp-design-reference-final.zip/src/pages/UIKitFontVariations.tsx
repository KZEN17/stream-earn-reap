import React from 'react'
import { Type, Palette, ArrowRight, Check } from 'lucide-react'
import Button from '../components/ui/Button'
import Card from '../components/ui/Card'
import FontThemeToggle from '../components/ui/FontThemeToggle'

const UIKitFontVariations: React.FC = () => {
  return (
    <div className="min-h-screen bg-bg-primary text-text-primary">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary/10 via-accent/10 to-accent-secondary/10 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-head font-bold mb-4 text-gradient">
                UI Kit – Font Variations
              </h1>
              <p className="text-lg font-body text-text-secondary max-w-2xl">
                Explore our complete typography system with dynamic font switching capabilities. 
                Compare Space Grotesk and Clash Display for headings while maintaining Inter for body text.
              </p>
            </div>
            <FontThemeToggle />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-16">
        {/* Side-by-Side Comparison */}
        <section className="mb-16">
          <h2 className="text-3xl font-head font-bold mb-8 text-center text-primary">
            Font Theme Comparison
          </h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Space Grotesk Theme */}
            <Card variant="default">
              <div className="p-8">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-head font-bold text-primary">Space Grotesk Theme</h3>
                  <span className="text-xs bg-primary/20 text-primary px-3 py-1 rounded-theme-sm font-body">
                    DEFAULT
                  </span>
                </div>
                
                {/* Typography Examples */}
                <div className="space-y-6">
                  <div>
                    <h1 className="text-3xl font-space font-bold text-text-primary mb-2">
                      Main Heading
                    </h1>
                    <p className="font-inter text-text-secondary">
                      This is body text using Inter font. It provides excellent readability 
                      and is optimized for digital interfaces across all screen sizes.
                    </p>
                  </div>
                  
                  <div>
                    <h2 className="text-2xl font-space font-semibold text-text-primary mb-2">
                      Section Title
                    </h2>
                    <p className="font-inter text-sm text-text-tertiary">
                      Space Grotesk offers a modern, geometric aesthetic that's perfect 
                      for gaming and technology-focused applications.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-space font-medium text-text-primary mb-2">
                      Component Heading
                    </h3>
                    <p className="font-inter text-text-secondary">
                      The combination creates a clean, professional look that appeals 
                      to tech-savvy audiences.
                    </p>
                  </div>
                </div>
                
                {/* Features List */}
                <div className="mt-8 pt-6 border-t border-white/10">
                  <h4 className="font-space font-semibold text-text-primary mb-4">Features:</h4>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 font-inter text-sm text-text-secondary">
                      <Check size={16} className="text-primary" />
                      Geometric, modern aesthetic
                    </li>
                    <li className="flex items-center gap-2 font-inter text-sm text-text-secondary">
                      <Check size={16} className="text-primary" />
                      Gaming & tech focused
                    </li>
                    <li className="flex items-center gap-2 font-inter text-sm text-text-secondary">
                      <Check size={16} className="text-primary" />
                      Sharp, clean lines
                    </li>
                  </ul>
                </div>
              </div>
            </Card>

            {/* Clash Display Theme */}
            <Card variant="default">
              <div className="p-8">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-head font-bold text-accent">Clash Display Theme</h3>
                  <span className="text-xs bg-accent/20 text-accent px-3 py-1 rounded-theme-sm font-body">
                    ALTERNATE
                  </span>
                </div>
                
                {/* Typography Examples */}
                <div className="space-y-6">
                  <div>
                    <h1 className="text-3xl font-clash font-bold text-text-primary mb-2">
                      Main Heading
                    </h1>
                    <p className="font-inter text-text-secondary">
                      This is body text using Inter font. It provides excellent readability 
                      and is optimized for digital interfaces across all screen sizes.
                    </p>
                  </div>
                  
                  <div>
                    <h2 className="text-2xl font-clash font-semibold text-text-primary mb-2">
                      Section Title
                    </h2>
                    <p className="font-inter text-sm text-text-tertiary">
                      Clash Display brings a more expressive, creative personality 
                      while maintaining professional readability standards.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-clash font-medium text-text-primary mb-2">
                      Component Heading
                    </h3>
                    <p className="font-inter text-text-secondary">
                      This combination offers a more artistic, creative approach 
                      perfect for content creators and designers.
                    </p>
                  </div>
                </div>
                
                {/* Features List */}
                <div className="mt-8 pt-6 border-t border-white/10">
                  <h4 className="font-clash font-semibold text-text-primary mb-4">Features:</h4>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 font-inter text-sm text-text-secondary">
                      <Check size={16} className="text-accent" />
                      Expressive, creative design
                    </li>
                    <li className="flex items-center gap-2 font-inter text-sm text-text-secondary">
                      <Check size={16} className="text-accent" />
                      Content creator focused
                    </li>
                    <li className="flex items-center gap-2 font-inter text-sm text-text-secondary">
                      <Check size={16} className="text-accent" />
                      Artistic personality
                    </li>
                  </ul>
                </div>
              </div>
            </Card>
          </div>
        </section>

        {/* Component Examples */}
        <section className="mb-16">
          <h2 className="text-3xl font-head font-bold mb-8 text-center text-accent">
            Component Examples
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Navigation Card */}
            <Card variant="default">
              <div className="p-6">
                <h3 className="font-head font-semibold mb-4 text-primary">Navigation</h3>
                <div className="glass-panel p-4 rounded-theme-lg">
                  <div className="flex items-center justify-between mb-4">
                    <span className="font-head font-bold text-gradient">ClipStream</span>
                    <Button variant="primary" size="sm">
                      <span className="font-body">Login</span>
                    </Button>
                  </div>
                  <nav className="space-y-2">
                    <a href="#" className="block font-body text-text-secondary hover:text-primary transition-colors">
                      Dashboard
                    </a>
                    <a href="#" className="block font-body text-text-secondary hover:text-primary transition-colors">
                      Streams
                    </a>
                    <a href="#" className="block font-body text-text-secondary hover:text-primary transition-colors">
                      Settings
                    </a>
                  </nav>
                </div>
              </div>
            </Card>

            {/* CTA Card */}
            <Card variant="default">
              <div className="p-6">
                <h3 className="font-head font-semibold mb-4 text-accent">Call to Action</h3>
                <div className="text-center glass-panel p-6 rounded-theme-lg">
                  <h4 className="text-xl font-head font-bold text-primary mb-3">
                    Join Today
                  </h4>
                  <p className="font-body text-text-secondary mb-4 text-sm">
                    Start your streaming journey with our powerful platform.
                  </p>
                  <Button variant="primary" className="w-full">
                    <span className="font-body">Get Started</span>
                  </Button>
                </div>
              </div>
            </Card>

            {/* Stats Card */}
            <Card variant="default">
              <div className="p-6">
                <h3 className="font-head font-semibold mb-4 text-accent-secondary">Statistics</h3>
                <div className="glass-panel p-4 rounded-theme-lg space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="font-body text-text-secondary">Total Views</span>
                    <span className="font-head font-bold text-primary">1.2M</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-body text-text-secondary">Followers</span>
                    <span className="font-head font-bold text-accent">45.6K</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-body text-text-secondary">Clips</span>
                    <span className="font-head font-bold text-accent-secondary">892</span>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </section>

        {/* Implementation Guide */}
        <section>
          <h2 className="text-3xl font-head font-bold mb-8 text-center text-gradient">
            Implementation Guide
          </h2>
          
          <Card variant="default">
            <div className="p-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <h3 className="font-head font-semibold mb-4 text-primary">CSS Variables</h3>
                  <div className="bg-bg-secondary rounded-theme-lg p-4 font-mono text-sm">
                    <div className="text-text-secondary mb-2">/* Default Theme */</div>
                    <div className="text-primary">--font-head: 'Space Grotesk', sans-serif;</div>
                    <div className="text-primary">--font-body: 'Inter', sans-serif;</div>
                    <div className="text-text-secondary mt-4 mb-2">/* Alt Theme */</div>
                    <div className="text-accent">--font-head: 'Clash Display', sans-serif;</div>
                    <div className="text-accent">--font-body: 'Inter', sans-serif;</div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-head font-semibold mb-4 text-accent">Tailwind Classes</h3>
                  <div className="bg-bg-secondary rounded-theme-lg p-4 font-mono text-sm">
                    <div className="text-text-secondary mb-2">/* For headings */</div>
                    <div className="text-primary">className="font-head"</div>
                    <div className="text-text-secondary mt-4 mb-2">/* For body text */</div>
                    <div className="text-accent">className="font-body"</div>
                    <div className="text-text-secondary mt-4 mb-2">/* Direct font access */</div>
                    <div className="text-accent-secondary">className="font-space | font-clash | font-inter"</div>
                  </div>
                </div>
              </div>
              
              <div className="mt-8 pt-6 border-t border-white/10">
                <h3 className="font-head font-semibold mb-4 text-accent-secondary">Usage Guidelines</h3>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <li className="flex items-start gap-2 font-body text-text-secondary">
                    <ArrowRight size={16} className="text-primary mt-1 flex-shrink-0" />
                    Use font-head for all headings (h1-h6) and titles
                  </li>
                  <li className="flex items-start gap-2 font-body text-text-secondary">
                    <ArrowRight size={16} className="text-primary mt-1 flex-shrink-0" />
                    Use font-body for paragraphs, labels, and UI text
                  </li>
                  <li className="flex items-start gap-2 font-body text-text-secondary">
                    <ArrowRight size={16} className="text-primary mt-1 flex-shrink-0" />
                    Themes switch automatically via CSS variables
                  </li>
                  <li className="flex items-start gap-2 font-body text-text-secondary">
                    <ArrowRight size={16} className="text-primary mt-1 flex-shrink-0" />
                    Inter remains consistent across all themes
                  </li>
                </ul>
              </div>
            </div>
          </Card>
        </section>
      </div>
    </div>
  )
}

export default UIKitFontVariations
