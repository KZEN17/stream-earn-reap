import React from 'react'
import { motion } from 'framer-motion'
import { Trophy, DollarSign, TrendingUp, Gift } from 'lucide-react'

const Rewards: React.FC = () => {
  const rewards = [
    {
      id: 1,
      title: 'Top Clipper',
      description: 'Most viral clips this month',
      amount: '$500',
      progress: 85,
      icon: Trophy,
      color: '#3CFF88'
    },
    {
      id: 2,
      title: 'Stream Consistency',
      description: '30 days streaming streak',
      amount: '$250',
      progress: 60,
      icon: TrendingUp,
      color: '#00E0FF'
    },
    {
      id: 3,
      title: 'Community Builder',
      description: 'Most engaging content',
      amount: '$150',
      progress: 40,
      icon: Gift,
      color: '#FF1B8D'
    }
  ]

  return (
    <div className="p-4 lg:p-8 space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 
          className="text-4xl font-bold mb-4"
          style={{ 
            fontFamily: 'Space Grotesk, sans-serif',
            color: '#3CFF88',
            textShadow: '0 0 10px rgba(60, 255, 136, 0.5)'
          }}
        >
          Rewards
        </h1>
        <p className="text-xl" style={{ color: '#D1D5DB' }}>
          Track your earnings and achievements
        </p>
      </motion.div>

      <div className="grid gap-6">
        {rewards.map((reward, index) => {
          const Icon = reward.icon
          return (
            <motion.div
              key={reward.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="p-6 rounded-lg transition-all duration-300"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.05)',
                backdropFilter: 'blur(12px)',
                border: '1px solid rgba(255, 255, 255, 0.1)'
              }}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div 
                    className="p-3 rounded-lg"
                    style={{ backgroundColor: `${reward.color}20` }}
                  >
                    <Icon className="w-6 h-6" style={{ color: reward.color }} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">{reward.title}</h3>
                    <p className="text-sm" style={{ color: '#9CA3AF' }}>{reward.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold" style={{ color: reward.color }}>
                    {reward.amount}
                  </div>
                  <div className="text-sm" style={{ color: '#9CA3AF' }}>
                    {reward.progress}% complete
                  </div>
                </div>
              </div>
              
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div 
                  className="h-2 rounded-full transition-all duration-500"
                  style={{ 
                    width: `${reward.progress}%`,
                    backgroundColor: reward.color
                  }}
                />
              </div>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}

export default Rewards
