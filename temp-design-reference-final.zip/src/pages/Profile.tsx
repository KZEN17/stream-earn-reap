import React from 'react'
import { motion } from 'framer-motion'
import { User, Settings, BarChart3, DollarSign } from 'lucide-react'

const Profile: React.FC = () => {
  const stats = [
    { label: 'Total Earnings', value: '$1,234.56', icon: DollarSign, color: '#3CFF88' },
    { label: 'Clips Created', value: '156', icon: BarChart3, color: '#00E0FF' },
    { label: 'Total Views', value: '2.1M', icon: BarChart3, color: '#FF1B8D' },
  ]

  return (
    <div className="p-4 lg:p-8 space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div 
          className="w-24 h-24 rounded-full mx-auto mb-4 flex items-center justify-center text-2xl font-bold"
          style={{ backgroundColor: '#3CFF88', color: '#000' }}
        >
          U
        </div>
        <h1 
          className="text-4xl font-bold mb-2"
          style={{ 
            fontFamily: 'Space Grotesk, sans-serif',
            color: '#3CFF88',
            textShadow: '0 0 10px rgba(60, 255, 136, 0.5)'
          }}
        >
          Your Profile
        </h1>
        <p className="text-xl" style={{ color: '#D1D5DB' }}>
          @username
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="p-6 rounded-lg text-center"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.05)',
                backdropFilter: 'blur(12px)',
                border: '1px solid rgba(255, 255, 255, 0.1)'
              }}
            >
              <div 
                className="w-12 h-12 rounded-lg mx-auto mb-4 flex items-center justify-center"
                style={{ backgroundColor: `${stat.color}20` }}
              >
                <Icon className="w-6 h-6" style={{ color: stat.color }} />
              </div>
              <div className="text-2xl font-bold mb-2" style={{ color: stat.color }}>
                {stat.value}
              </div>
              <div className="text-sm" style={{ color: '#9CA3AF' }}>
                {stat.label}
              </div>
            </motion.div>
          )
        })}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="p-6 rounded-lg"
        style={{
          backgroundColor: 'rgba(255, 255, 255, 0.05)',
          backdropFilter: 'blur(12px)',
          border: '1px solid rgba(255, 255, 255, 0.1)'
        }}
      >
        <h3 className="text-xl font-bold mb-4 text-white">Account Settings</h3>
        <div className="space-y-3">
          <button className="w-full text-left p-3 rounded-lg transition-colors" style={{ color: '#D1D5DB' }}>
            Edit Profile
          </button>
          <button className="w-full text-left p-3 rounded-lg transition-colors" style={{ color: '#D1D5DB' }}>
            Payment Settings
          </button>
          <button className="w-full text-left p-3 rounded-lg transition-colors" style={{ color: '#D1D5DB' }}>
            Privacy Settings
          </button>
        </div>
      </motion.div>
    </div>
  )
}

export default Profile
