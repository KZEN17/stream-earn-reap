import React from 'react'
import { motion } from 'framer-motion'
import { Trophy, Medal, Award } from 'lucide-react'

const Leaderboards: React.FC = () => {
  const leaders = [
    { id: 1, rank: 1, name: 'ProGamer123', score: 15420, earnings: '$1,250' },
    { id: 2, rank: 2, name: 'MusicMaster', score: 12890, earnings: '$980' },
    { id: 3, rank: 3, name: 'ClipKing', score: 11560, earnings: '$875' },
    { id: 4, rank: 4, name: 'StreamQueen', score: 9870, earnings: '$720' },
    { id: 5, rank: 5, name: 'ContentCreator', score: 8450, earnings: '$650' },
  ]

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Trophy className="w-6 h-6 text-yellow-400" />
      case 2: return <Medal className="w-6 h-6 text-gray-400" />
      case 3: return <Award className="w-6 h-6 text-amber-600" />
      default: return <span className="text-lg font-bold text-gray-400">#{rank}</span>
    }
  }

  return (
    <div className="p-4 lg:p-8 space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 
          className="text-4xl font-bold mb-4"
          style={{ 
            fontFamily: 'Space Grotesk, sans-serif',
            color: '#3CFF88',
            textShadow: '0 0 10px rgba(60, 255, 136, 0.5)'
          }}
        >
          Leaderboards
        </h1>
        <p className="text-xl" style={{ color: '#D1D5DB' }}>
          Top performers this month
        </p>
      </motion.div>

      <div className="space-y-4">
        {leaders.map((leader, index) => (
          <motion.div
            key={leader.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-4 rounded-lg transition-all duration-300 flex items-center justify-between"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.05)',
              backdropFilter: 'blur(12px)',
              border: '1px solid rgba(255, 255, 255, 0.1)'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.05)'
            }}
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 flex items-center justify-center">
                {getRankIcon(leader.rank)}
              </div>
              <div>
                <h3 className="font-bold text-white">{leader.name}</h3>
                <p className="text-sm" style={{ color: '#9CA3AF' }}>
                  {leader.score.toLocaleString()} points
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="font-bold" style={{ color: '#3CFF88' }}>
                {leader.earnings}
              </div>
              <div className="text-sm" style={{ color: '#9CA3AF' }}>
                earned
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

export default Leaderboards
