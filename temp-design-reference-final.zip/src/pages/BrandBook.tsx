import React from 'react'
import { Download, Copy, Check } from 'lucide-react'
import { useState } from 'react'

const BrandBook: React.FC = () => {
  const [copiedColor, setCopiedColor] = useState<string | null>(null)

  const copyToClipboard = (text: string, colorName: string) => {
    navigator.clipboard.writeText(text)
    setCopiedColor(colorName)
    setTimeout(() => setCopiedColor(null), 2000)
  }

  const colors = {
    primary: {
      dark: { name: 'Dark Base', value: '#0B0C0E', description: 'Primary background' },
      darkSecondary: { name: 'Dark Secondary', value: '#212529', description: 'Secondary surfaces' }
    },
    neon: {
      pink: { name: 'Neon Pink', value: '#FF1B8D', description: 'Primary accent' },
      purple: { name: 'Neon Purple', value: '#8B5FFF', description: 'Secondary accent' },
      cyan: { name: 'Neon Cyan', value: '#00CFFF', description: 'Info & highlights' },
      green: { name: 'Neon Green', value: '#3CFF88', description: 'Success & earnings' },
      yellow: { name: 'Neon Yellow', value: '#E5FF00', description: 'Warnings & alerts' }
    }
  }

  const gradients = [
    { name: 'Pink to Purple', css: 'linear-gradient(135deg, #FF1B8D 0%, #8B5FFF 100%)' },
    { name: 'Purple to Blue', css: 'linear-gradient(135deg, #8B5FFF 0%, #00CFFF 100%)' },
    { name: 'Magenta to Cyan', css: 'linear-gradient(135deg, #FF1B8D 0%, #00CFFF 100%)' },
    { name: 'Rainbow Glow', css: 'linear-gradient(135deg, #3CFF88 0%, #00CFFF 33%, #8B5FFF 66%, #FF1B8D 100%)' }
  ]

  return (
    <div className="min-h-screen bg-dark-950 text-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-neon-magenta/20 via-neon-purple/20 to-neon-cyan/20 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-5xl font-bold mb-4">
                <span className="text-gradient">CLIP</span> Brand Guidelines
              </h1>
              <p className="text-xl text-gray-300">Stream • Clip • Earn $</p>
            </div>
            <button className="btn-primary flex items-center gap-2">
              <Download size={20} />
              Download Assets
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-12 space-y-16">
        {/* Logo System */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-green">Logo System</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Primary Logo */}
            <div className="glass-panel p-8 text-center">
              <div className="mb-6">
                <div className="inline-flex items-center gap-3 text-4xl font-bold">
                  <div className="w-12 h-12 bg-gradient-to-br from-neon-magenta to-neon-cyan rounded-lg flex items-center justify-center">
                    <span className="text-white font-black">C</span>
                  </div>
                  <span className="text-gradient">CLIP</span>
                </div>
              </div>
              <h3 className="font-semibold mb-2">Primary Logo</h3>
              <p className="text-sm text-gray-400">Full wordmark with icon</p>
            </div>

            {/* Icon Only */}
            <div className="glass-panel p-8 text-center">
              <div className="mb-6 flex justify-center">
                <div className="w-16 h-16 bg-gradient-to-br from-neon-magenta to-neon-cyan rounded-xl flex items-center justify-center">
                  <span className="text-white font-black text-2xl">C</span>
                </div>
              </div>
              <h3 className="font-semibold mb-2">Icon Only</h3>
              <p className="text-sm text-gray-400">For small spaces</p>
            </div>

            {/* Monochrome */}
            <div className="glass-panel p-8 text-center">
              <div className="mb-6">
                <div className="inline-flex items-center gap-3 text-4xl font-bold text-white">
                  <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                    <span className="text-black font-black">C</span>
                  </div>
                  <span>CLIP</span>
                </div>
              </div>
              <h3 className="font-semibold mb-2">Monochrome</h3>
              <p className="text-sm text-gray-400">Single color version</p>
            </div>

            {/* Favicon */}
            <div className="glass-panel p-8 text-center">
              <div className="mb-6 flex justify-center">
                <div className="w-8 h-8 bg-gradient-to-br from-neon-magenta to-neon-cyan rounded flex items-center justify-center">
                  <span className="text-white font-black text-sm">C</span>
                </div>
              </div>
              <h3 className="font-semibold mb-2">Favicon</h3>
              <p className="text-sm text-gray-400">16x16 / 32x32 px</p>
            </div>
          </div>
        </section>

        {/* Color Palette */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-cyan">Color Palette</h2>
          
          {/* Primary Colors */}
          <div className="mb-8">
            <h3 className="text-xl font-semibold mb-4">Primary Colors</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {Object.entries(colors.primary).map(([key, color]) => (
                <div key={key} className="glass-panel p-4">
                  <div 
                    className="w-full h-20 rounded-lg mb-3 border border-white/10"
                    style={{ backgroundColor: color.value }}
                  ></div>
                  <h4 className="font-semibold text-sm">{color.name}</h4>
                  <p className="text-xs text-gray-400 mb-2">{color.description}</p>
                  <button
                    onClick={() => copyToClipboard(color.value, key)}
                    className="flex items-center gap-1 text-xs text-neon-green hover:text-neon-cyan transition-colors"
                  >
                    {copiedColor === key ? <Check size={12} /> : <Copy size={12} />}
                    {color.value}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Neon Accents */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Neon Accents</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {Object.entries(colors.neon).map(([key, color]) => (
                <div key={key} className="glass-panel p-4">
                  <div 
                    className="w-full h-20 rounded-lg mb-3 border border-white/10"
                    style={{ 
                      backgroundColor: color.value,
                      boxShadow: `0 0 20px ${color.value}40`
                    }}
                  ></div>
                  <h4 className="font-semibold text-sm">{color.name}</h4>
                  <p className="text-xs text-gray-400 mb-2">{color.description}</p>
                  <button
                    onClick={() => copyToClipboard(color.value, key)}
                    className="flex items-center gap-1 text-xs text-neon-green hover:text-neon-cyan transition-colors"
                  >
                    {copiedColor === key ? <Check size={12} /> : <Copy size={12} />}
                    {color.value}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Typography */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-purple">Typography</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Headings */}
            <div className="glass-panel p-8">
              <h3 className="text-xl font-semibold mb-6">Headings - Space Grotesk</h3>
              <div className="space-y-4">
                <div>
                  <h1 className="text-4xl font-bold text-gradient">Heading 1</h1>
                  <p className="text-sm text-gray-400">40px / Bold / Uppercase</p>
                </div>
                <div>
                  <h2 className="text-3xl font-bold text-neon-green">Heading 2</h2>
                  <p className="text-sm text-gray-400">32px / Bold</p>
                </div>
                <div>
                  <h3 className="text-2xl font-semibold text-neon-cyan">Heading 3</h3>
                  <p className="text-sm text-gray-400">24px / Semibold</p>
                </div>
                <div>
                  <h4 className="text-xl font-medium text-white">Heading 4</h4>
                  <p className="text-sm text-gray-400">20px / Medium</p>
                </div>
              </div>
            </div>

            {/* Body Text */}
            <div className="glass-panel p-8">
              <h3 className="text-xl font-semibold mb-6">Body Text - Inter</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-lg text-white">Large Body Text</p>
                  <p className="text-sm text-gray-400">18px / Regular</p>
                </div>
                <div>
                  <p className="text-base text-white">Regular Body Text</p>
                  <p className="text-sm text-gray-400">16px / Regular</p>
                </div>
                <div>
                  <p className="text-sm text-gray-300">Small Body Text</p>
                  <p className="text-xs text-gray-400">14px / Regular</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Caption Text</p>
                  <p className="text-xs text-gray-500">12px / Regular</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Gradients */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-yellow">Gradients</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {gradients.map((gradient, index) => (
              <div key={index} className="glass-panel p-6">
                <div 
                  className="w-full h-24 rounded-lg mb-4"
                  style={{ background: gradient.css }}
                ></div>
                <h4 className="font-semibold mb-2">{gradient.name}</h4>
                <button
                  onClick={() => copyToClipboard(gradient.css, `gradient-${index}`)}
                  className="flex items-center gap-1 text-xs text-neon-green hover:text-neon-cyan transition-colors"
                >
                  {copiedColor === `gradient-${index}` ? <Check size={12} /> : <Copy size={12} />}
                  Copy CSS
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* UI Components Preview */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-magenta">UI Components</h2>
          
          {/* Buttons */}
          <div className="mb-12">
            <h3 className="text-xl font-semibold mb-6">Buttons</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="glass-panel p-6">
                <h4 className="font-semibold mb-4">Primary</h4>
                <div className="space-y-3">
                  <button className="w-full bg-gradient-to-r from-neon-magenta to-neon-purple px-6 py-3 rounded-lg font-medium text-white hover:shadow-neon-magenta transition-all">
                    Primary Button
                  </button>
                  <button className="w-full bg-gradient-to-r from-neon-magenta to-neon-purple px-6 py-3 rounded-lg font-medium text-white opacity-50 cursor-not-allowed">
                    Disabled
                  </button>
                </div>
              </div>
              
              <div className="glass-panel p-6">
                <h4 className="font-semibold mb-4">Secondary</h4>
                <div className="space-y-3">
                  <button className="w-full border-2 border-neon-cyan text-neon-cyan px-6 py-3 rounded-lg font-medium hover:bg-neon-cyan/10 transition-all">
                    Secondary Button
                  </button>
                  <button className="w-full border-2 border-gray-600 text-gray-600 px-6 py-3 rounded-lg font-medium cursor-not-allowed">
                    Disabled
                  </button>
                </div>
              </div>
              
              <div className="glass-panel p-6">
                <h4 className="font-semibold mb-4">Tertiary</h4>
                <div className="space-y-3">
                  <button className="w-full text-neon-green px-6 py-3 rounded-lg font-medium hover:bg-neon-green/10 transition-all">
                    Tertiary Button
                  </button>
                  <button className="w-full text-gray-600 px-6 py-3 rounded-lg font-medium cursor-not-allowed">
                    Disabled
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Cards */}
          <div className="mb-12">
            <h3 className="text-xl font-semibold mb-6">Cards</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="glass-panel p-6 hover:bg-glass-medium transition-all">
                <h4 className="font-semibold mb-2">Default Card</h4>
                <p className="text-gray-400 text-sm">Basic card component with glass morphism effect</p>
              </div>
              
              <div className="glass-panel p-6 border-l-4 border-neon-green hover:bg-glass-medium transition-all">
                <h4 className="font-semibold mb-2 text-neon-green">Campaign Card</h4>
                <p className="text-gray-400 text-sm">Featured campaign with accent border</p>
              </div>
              
              <div className="glass-panel p-6 hover:bg-glass-medium transition-all group">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-gradient-to-br from-neon-magenta to-neon-cyan rounded-full"></div>
                  <h4 className="font-semibold">Profile Card</h4>
                </div>
                <p className="text-gray-400 text-sm">User profile with avatar</p>
              </div>
            </div>
          </div>

          {/* Progress Indicators */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Progress Indicators</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="glass-panel p-6">
                <h4 className="font-semibold mb-4">Linear Progress</h4>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Campaign Progress</span>
                      <span>75%</span>
                    </div>
                    <div className="h-2 bg-dark-800 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-neon-green to-neon-cyan w-3/4 transition-all duration-500"></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Earnings</span>
                      <span>45%</span>
                    </div>
                    <div className="h-2 bg-dark-800 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-neon-magenta to-neon-purple w-2/5 transition-all duration-500"></div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="glass-panel p-6">
                <h4 className="font-semibold mb-4">Circular Progress</h4>
                <div className="flex justify-center">
                  <div className="relative w-24 h-24">
                    <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 100 100">
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="transparent"
                        className="text-dark-800"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="url(#gradient)"
                        strokeWidth="8"
                        fill="transparent"
                        strokeDasharray={`${2 * Math.PI * 40}`}
                        strokeDashoffset={`${2 * Math.PI * 40 * (1 - 0.65)}`}
                        className="transition-all duration-500"
                      />
                      <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#3CFF88" />
                          <stop offset="100%" stopColor="#00CFFF" />
                        </linearGradient>
                      </defs>
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-lg font-semibold">65%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Social Media Mockups */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-neon-cyan">Social Media Assets</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Twitter Banner */}
            <div className="glass-panel p-4">
              <h4 className="font-semibold mb-4">Twitter/X Banner</h4>
              <div className="aspect-[3/1] bg-gradient-to-r from-neon-magenta/20 via-neon-purple/20 to-neon-cyan/20 rounded-lg flex items-center justify-center border border-white/10">
                <div className="text-center">
                  <div className="inline-flex items-center gap-2 text-2xl font-bold mb-2">
                    <div className="w-8 h-8 bg-gradient-to-br from-neon-magenta to-neon-cyan rounded-lg flex items-center justify-center">
                      <span className="text-white font-black text-sm">C</span>
                    </div>
                    <span className="text-gradient">CLIP</span>
                  </div>
                  <p className="text-sm text-gray-300">Stream • Clip • Earn $</p>
                </div>
              </div>
              <p className="text-xs text-gray-400 mt-2">1500x500px</p>
            </div>

            {/* Discord Banner */}
            <div className="glass-panel p-4">
              <h4 className="font-semibold mb-4">Discord Banner</h4>
              <div className="aspect-[16/9] bg-gradient-to-br from-neon-purple/20 to-neon-magenta/20 rounded-lg flex items-center justify-center border border-white/10">
                <div className="text-center">
                  <div className="inline-flex items-center gap-3 text-3xl font-bold mb-2">
                    <div className="w-10 h-10 bg-gradient-to-br from-neon-magenta to-neon-cyan rounded-xl flex items-center justify-center">
                      <span className="text-white font-black">C</span>
                    </div>
                    <span className="text-gradient">CLIP</span>
                  </div>
                  <p className="text-gray-300">Join the Community</p>
                </div>
              </div>
              <p className="text-xs text-gray-400 mt-2">960x540px</p>
            </div>

            {/* Profile Icon */}
            <div className="glass-panel p-4">
              <h4 className="font-semibold mb-4">Profile Icons</h4>
              <div className="flex justify-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-neon-magenta to-neon-cyan rounded-full flex items-center justify-center">
                  <span className="text-white font-black text-xl">C</span>
                </div>
                <div className="w-16 h-16 bg-gradient-to-br from-neon-magenta to-neon-cyan rounded-lg flex items-center justify-center">
                  <span className="text-white font-black text-xl">C</span>
                </div>
              </div>
              <p className="text-xs text-gray-400 mt-2 text-center">512x512px</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

export default BrandBook
