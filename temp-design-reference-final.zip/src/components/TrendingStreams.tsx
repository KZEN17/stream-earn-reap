import React from 'react'
import { motion } from 'framer-motion'
import { Eye, Users, Clock } from 'lucide-react'

const TrendingStreams: React.FC = () => {
  const streams = [
    {
      id: 1,
      title: 'Epic Gaming Marathon',
      streamer: 'ProGamer123',
      viewers: '12.5K',
      duration: '4h 23m',
      thumbnail: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=300&h=200&fit=crop',
      category: 'Gaming'
    },
    {
      id: 2,
      title: 'Music Production Live',
      streamer: 'BeatMaker',
      viewers: '8.2K',
      duration: '2h 15m',
      thumbnail: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=200&fit=crop',
      category: 'Music'
    },
    {
      id: 3,
      title: 'Cooking with Chef Mike',
      streamer: 'ChefMike',
      viewers: '5.7K',
      duration: '1h 45m',
      thumbnail: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop',
      category: 'Cooking'
    }
  ]

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 
          className="text-2xl font-bold"
          style={{ 
            fontFamily: 'Space Grotesk, sans-serif',
            color: '#3CFF88',
            textShadow: '0 0 10px rgba(60, 255, 136, 0.5)'
          }}
        >
          Trending Streams
        </h2>
        <button 
          className="text-sm font-medium transition-colors"
          style={{ color: '#00E0FF' }}
          onMouseEnter={(e) => e.target.style.color = '#3CFF88'}
          onMouseLeave={(e) => e.target.style.color = '#00E0FF'}
        >
          View All
        </button>
      </div>

      <div className="space-y-4">
        {streams.map((stream, index) => (
          <motion.div
            key={stream.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-4 rounded-lg transition-all duration-300 cursor-pointer"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.05)',
              backdropFilter: 'blur(12px)',
              border: '1px solid rgba(255, 255, 255, 0.1)'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)'
              e.currentTarget.style.borderColor = 'rgba(60, 255, 136, 0.5)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.05)'
              e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)'
            }}
          >
            <div className="flex gap-4">
              <div className="relative">
                <img
                  src={stream.thumbnail}
                  alt={stream.title}
                  className="w-20 h-14 object-cover rounded-lg"
                />
                <div 
                  className="absolute top-1 right-1 px-1 py-0.5 rounded text-xs font-medium"
                  style={{ backgroundColor: '#EF4444', color: 'white' }}
                >
                  LIVE
                </div>
              </div>
              
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-white truncate mb-1">
                  {stream.title}
                </h3>
                <p className="text-sm mb-2" style={{ color: '#9CA3AF' }}>
                  {stream.streamer}
                </p>
                
                <div className="flex items-center gap-4 text-xs" style={{ color: '#6B7280' }}>
                  <div className="flex items-center gap-1">
                    <Eye className="w-3 h-3" />
                    <span>{stream.viewers}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{stream.duration}</span>
                  </div>
                  <span 
                    className="px-2 py-0.5 rounded-full text-xs"
                    style={{ 
                      backgroundColor: 'rgba(60, 255, 136, 0.2)',
                      color: '#3CFF88'
                    }}
                  >
                    {stream.category}
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

export default TrendingStreams
