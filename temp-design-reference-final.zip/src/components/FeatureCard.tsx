import React from 'react'
import { motion } from 'framer-motion'
import { LucideIcon } from 'lucide-react'

interface FeatureCardProps {
  icon: LucideIcon
  title: string
  description: string
  color: string
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon: Icon, title, description, color }) => {
  const getColor = (colorName: string) => {
    switch (colorName) {
      case 'neon-green': return '#3CFF88'
      case 'neon-cyan': return '#00E0FF'
      case 'neon-magenta': return '#FF1B8D'
      default: return '#3CFF88'
    }
  }

  const iconColor = getColor(color)

  return (
    <motion.div
      whileHover={{ scale: 1.05, y: -5 }}
      className="p-8 rounded-lg transition-all duration-300 cursor-pointer"
      style={{
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        backdropFilter: 'blur(12px)',
        border: '1px solid rgba(255, 255, 255, 0.1)'
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)'
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.05)'
      }}
    >
      <div 
        className="w-12 h-12 rounded-lg flex items-center justify-center mb-6"
        style={{ backgroundColor: `${iconColor}20` }}
      >
        <Icon className="w-6 h-6" style={{ color: iconColor }} />
      </div>
      
      <h3 className="text-xl font-bold mb-3" style={{ color: iconColor }}>
        {title}
      </h3>
      
      <p className="leading-relaxed" style={{ color: '#D1D5DB' }}>
        {description}
      </p>
    </motion.div>
  )
}

export default FeatureCard
