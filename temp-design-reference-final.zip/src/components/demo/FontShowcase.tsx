import React from 'react'
import { Type, Palette, Eye, Settings } from 'lucide-react'
import Button from '../ui/Button'
import Card from '../ui/Card'
import FontThemeToggle from '../ui/FontThemeToggle'

const FontShowcase: React.FC = () => {
  return (
    <div className="min-h-screen bg-bg-primary text-text-primary">
      {/* Hero Section with Font Toggle */}
      <div className="bg-gradient-to-r from-primary/20 via-accent/20 to-accent-secondary/20 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-16">
          <div className="text-center">
            <div className="flex justify-center mb-8">
              <FontThemeToggle />
            </div>
            <h1 className="text-6xl font-head font-bold mb-6 text-gradient">
              Font Theme System
            </h1>
            <p className="text-xl font-body text-text-secondary mb-8 max-w-2xl mx-auto">
              Experience seamless font switching between Space Grotesk and Clash Display for headings, 
              while maintaining Inter for optimal body text readability.
            </p>
            <div className="flex gap-4 justify-center">
              <Button variant="primary" size="lg">
                <Eye size={20} className="mr-2" />
                Preview Fonts
              </Button>
              <Button variant="secondary" size="lg">
                <Settings size={20} className="mr-2" />
                Customize
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-16 space-y-16">
        {/* Font Comparison Section */}
        <section>
          <h2 className="text-4xl font-head font-bold mb-8 text-primary text-center">
            Typography Comparison
          </h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Default Theme Preview */}
            <Card variant="default">
              <div className="p-6">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-3 h-3 rounded-full bg-primary animate-pulse"></div>
                  <h3 className="font-head font-semibold text-primary">Default Theme</h3>
                  <span className="text-xs bg-primary/20 text-primary px-2 py-1 rounded-theme-sm">
                    Space Grotesk
                  </span>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="text-2xl font-head font-bold text-text-primary mb-2">
                      Heading Example
                    </h4>
                    <p className="font-body text-text-secondary">
                      This body text uses Inter font for optimal readability and consistency 
                      across all themes. Inter provides excellent legibility at all sizes.
                    </p>
                  </div>
                  
                  <div>
                    <h5 className="text-lg font-head font-semibold text-text-primary mb-2">
                      Subheading Style
                    </h5>
                    <p className="font-body text-sm text-text-tertiary">
                      Space Grotesk offers a modern, geometric aesthetic perfect for 
                      gaming and tech-focused applications.
                    </p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Alt Theme Preview */}
            <Card variant="default">
              <div className="p-6">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-3 h-3 rounded-full bg-accent animate-pulse"></div>
                  <h3 className="font-head font-semibold text-accent">Alternative Theme</h3>
                  <span className="text-xs bg-accent/20 text-accent px-2 py-1 rounded-theme-sm">
                    Clash Display
                  </span>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="text-2xl font-head font-bold text-text-primary mb-2">
                      Heading Example
                    </h4>
                    <p className="font-body text-text-secondary">
                      This body text uses Inter font for optimal readability and consistency 
                      across all themes. Inter provides excellent legibility at all sizes.
                    </p>
                  </div>
                  
                  <div>
                    <h5 className="text-lg font-head font-semibold text-text-primary mb-2">
                      Subheading Style
                    </h5>
                    <p className="font-body text-sm text-text-tertiary">
                      Clash Display brings a more expressive, creative personality 
                      while maintaining professional readability.
                    </p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </section>

        {/* Navigation Examples */}
        <section>
          <h2 className="text-4xl font-head font-bold mb-8 text-accent text-center">
            Navigation Components
          </h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Navbar Example */}
            <Card variant="default">
              <h3 className="font-head font-semibold mb-4 text-text-primary">Navigation Bar</h3>
              <div className="glass-panel p-4 rounded-theme-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-theme-lg bg-primary flex items-center justify-center">
                      <span className="text-black font-bold text-sm">C</span>
                    </div>
                    <span className="font-head font-bold text-gradient">ClipStream</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="tertiary" size="sm">
                      <span className="font-body">Login</span>
                    </Button>
                    <Button variant="primary" size="sm">
                      <span className="font-body">Sign Up</span>
                    </Button>
                  </div>
                </div>
              </div>
            </Card>

            {/* CTA Section */}
            <Card variant="default">
              <h3 className="font-head font-semibold mb-4 text-text-primary">Call to Action</h3>
              <div className="text-center p-6 glass-panel rounded-theme-lg">
                <h4 className="text-xl font-head font-bold text-primary mb-3">
                  Start Your Journey
                </h4>
                <p className="font-body text-text-secondary mb-4">
                  Join thousands of creators who trust our platform for their streaming needs.
                </p>
                <Button variant="primary" className="w-full">
                  <span className="font-body">Get Started Today</span>
                </Button>
              </div>
            </Card>
          </div>
        </section>

        {/* Typography Scale */}
        <section>
          <h2 className="text-4xl font-head font-bold mb-8 text-accent-secondary text-center">
            Typography Scale
          </h2>
          
          <Card variant="default">
            <div className="p-8 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Heading Styles */}
                <div>
                  <h3 className="font-head font-semibold mb-4 text-primary">Heading Styles</h3>
                  <div className="space-y-3">
                    <h1 className="text-4xl font-head font-bold text-text-primary">H1 - Main Title</h1>
                    <h2 className="text-3xl font-head font-bold text-text-primary">H2 - Section Title</h2>
                    <h3 className="text-2xl font-head font-semibold text-text-primary">H3 - Subsection</h3>
                    <h4 className="text-xl font-head font-semibold text-text-primary">H4 - Component Title</h4>
                    <h5 className="text-lg font-head font-medium text-text-primary">H5 - Small Heading</h5>
                    <h6 className="text-base font-head font-medium text-text-primary">H6 - Micro Heading</h6>
                  </div>
                </div>

                {/* Body Text Styles */}
                <div>
                  <h3 className="font-head font-semibold mb-4 text-accent">Body Text Styles</h3>
                  <div className="space-y-3">
                    <p className="text-lg font-body text-text-primary">Large body text for emphasis</p>
                    <p className="text-base font-body text-text-primary">Regular body text for content</p>
                    <p className="text-sm font-body text-text-secondary">Small text for captions</p>
                    <p className="text-xs font-body text-text-tertiary">Extra small text for metadata</p>
                    <p className="text-base font-body font-medium text-text-primary">Medium weight body text</p>
                    <p className="text-base font-body font-semibold text-text-primary">Semibold body text</p>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </section>

        {/* Implementation Guide */}
        <section>
          <h2 className="text-4xl font-head font-bold mb-8 text-gradient text-center">
            Implementation Guide
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card variant="default">
              <div className="p-6 text-center">
                <Type size={32} className="text-primary mx-auto mb-4" />
                <h3 className="font-head font-semibold mb-3 text-text-primary">CSS Variables</h3>
                <p className="font-body text-sm text-text-secondary">
                  Uses --font-head and --font-body CSS variables for seamless theme switching
                </p>
              </div>
            </Card>

            <Card variant="default">
              <div className="p-6 text-center">
                <Palette size={32} className="text-accent mx-auto mb-4" />
                <h3 className="font-head font-semibold mb-3 text-text-primary">Tailwind Classes</h3>
                <p className="font-body text-sm text-text-secondary">
                  Use font-head for headings and font-body for text content
                </p>
              </div>
            </Card>

            <Card variant="default">
              <div className="p-6 text-center">
                <Settings size={32} className="text-accent-secondary mx-auto mb-4" />
                <h3 className="font-head font-semibold mb-3 text-text-primary">Theme Toggle</h3>
                <p className="font-body text-sm text-text-secondary">
                  Instant switching between Space Grotesk and Clash Display
                </p>
              </div>
            </Card>
          </div>
        </section>
      </div>
    </div>
  )
}

export default FontShowcase
