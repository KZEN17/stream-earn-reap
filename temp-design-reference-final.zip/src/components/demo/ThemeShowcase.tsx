import React from 'react'
import { Play, Heart, Share2, Download, Settings, User, Star } from 'lucide-react'
import Button from '../ui/Button'
import Card from '../ui/Card'
import Input from '../ui/Input'
import Avatar from '../ui/Avatar'
import Progress from '../ui/Progress'

const ThemeShowcase: React.FC = () => {
  return (
    <div className="min-h-screen bg-bg-primary text-text-primary">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-primary/20 via-accent/20 to-accent-secondary/20 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-16">
          <div className="text-center">
            <h1 className="text-6xl font-head font-bold mb-6 text-gradient">
              Theme Showcase
            </h1>
            <p className="text-xl text-text-secondary mb-8 max-w-2xl mx-auto">
              Experience the power of dynamic theming with our complete UI kit variations. 
              Switch between themes seamlessly while maintaining perfect design consistency.
            </p>
            <div className="flex gap-4 justify-center">
              <Button variant="primary" size="lg">
                <Play size={20} className="mr-2" />
                Get Started
              </Button>
              <Button variant="secondary" size="lg">
                <Download size={20} className="mr-2" />
                Download Kit
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-16 space-y-16">
        {/* Navigation Demo */}
        <section>
          <h2 className="text-4xl font-head font-bold mb-8 text-primary">Navigation Components</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Navbar */}
            <Card variant="default">
              <h3 className="font-head font-semibold mb-4 text-text-primary">Navigation Bar</h3>
              <div className="glass-panel p-4 rounded-theme-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-theme-lg bg-primary flex items-center justify-center">
                      <span className="text-black font-bold text-sm">C</span>
                    </div>
                    <span className="font-head font-bold text-gradient">ClipStream</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="tertiary" size="sm">Login</Button>
                    <Button variant="primary" size="sm">Sign Up</Button>
                  </div>
                </div>
              </div>
            </Card>

            {/* Sidebar */}
            <Card variant="default">
              <h3 className="font-head font-semibold mb-4 text-text-primary">Sidebar Navigation</h3>
              <nav className="space-y-2">
                <a href="#" className="nav-link active">
                  <Play size={18} />
                  <span>Dashboard</span>
                </a>
                <a href="#" className="nav-link">
                  <Heart size={18} />
                  <span>Favorites</span>
                </a>
                <a href="#" className="nav-link">
                  <Settings size={18} />
                  <span>Settings</span>
                </a>
                <a href="#" className="nav-link">
                  <User size={18} />
                  <span>Profile</span>
                </a>
              </nav>
            </Card>
          </div>
        </section>

        {/* Button Variations */}
        <section>
          <h2 className="text-4xl font-head font-bold mb-8 text-accent">Button Components</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card variant="default">
              <h3 className="font-head font-semibold mb-4 text-text-primary">Primary Actions</h3>
              <div className="space-y-3">
                <Button variant="primary" className="w-full">
                  <Play size={16} className="mr-2" />
                  Start Stream
                </Button>
                <Button variant="primary" size="sm" className="w-full">
                  Quick Action
                </Button>
                <Button variant="primary" isLoading className="w-full">
                  Processing...
                </Button>
              </div>
            </Card>

            <Card variant="default">
              <h3 className="font-head font-semibold mb-4 text-text-primary">Secondary Actions</h3>
              <div className="space-y-3">
                <Button variant="secondary" className="w-full">
                  <Share2 size={16} className="mr-2" />
                  Share Clip
                </Button>
                <Button variant="secondary" size="sm" className="w-full">
                  Edit Settings
                </Button>
                <Button variant="secondary" disabled className="w-full">
                  Unavailable
                </Button>
              </div>
            </Card>

            <Card variant="default">
              <h3 className="font-head font-semibold mb-4 text-text-primary">Tertiary Actions</h3>
              <div className="space-y-3">
                <Button variant="tertiary" className="w-full">
                  <Heart size={16} className="mr-2" />
                  Add to Favorites
                </Button>
                <Button variant="ghost" className="w-full">
                  Cancel
                </Button>
                <Button variant="ghost" size="sm" className="w-full">
                  Learn More
                </Button>
              </div>
            </Card>
          </div>
        </section>

        {/* Card Variations */}
        <section>
          <h2 className="text-4xl font-head font-bold mb-8 text-accent-secondary">Card Components</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card variant="default">
              <div className="flex items-center gap-3 mb-4">
                <Avatar size="md" fallback="JS" />
                <div>
                  <h3 className="font-head font-semibold text-text-primary">John Streamer</h3>
                  <p className="text-sm text-text-secondary">@johnstreamer</p>
                </div>
              </div>
              <p className="text-text-secondary text-sm mb-4">
                Professional gamer and content creator with over 100K followers.
              </p>
              <div className="flex items-center gap-2 text-sm text-text-tertiary">
                <Star size={14} className="text-accent-secondary" />
                <span>4.9 rating</span>
                <span>•</span>
                <span>1.2K clips</span>
              </div>
            </Card>

            <Card variant="campaign">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-head font-semibold text-primary">Featured Campaign</h3>
                <span className="text-xs bg-primary/20 text-primary px-2 py-1 rounded-theme-sm">
                  LIVE
                </span>
              </div>
              <p className="text-text-secondary text-sm mb-4">
                Join our exclusive streaming campaign and earn rewards for your best clips.
              </p>
              <Progress value={75} showLabel className="mb-4" />
              <Button variant="primary" size="sm" className="w-full">
                Join Campaign
              </Button>
            </Card>

            <Card variant="profile">
              <div className="text-center">
                <Avatar size="lg" fallback="MC" className="mx-auto mb-4" />
                <h3 className="font-head font-semibold text-text-primary mb-2">Master Clipper</h3>
                <p className="text-text-secondary text-sm mb-4">Top performer this month</p>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-primary">$2,450</div>
                    <div className="text-xs text-text-tertiary">Earnings</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-accent">342</div>
                    <div className="text-xs text-text-tertiary">Clips</div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </section>

        {/* Form Elements */}
        <section>
          <h2 className="text-4xl font-head font-bold mb-8 text-primary">Form Components</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card variant="default">
              <h3 className="font-head font-semibold mb-6 text-text-primary">User Registration</h3>
              <div className="space-y-4">
                <Input
                  label="Username"
                  placeholder="Enter your username"
                  icon={<User size={16} />}
                />
                <Input
                  label="Email"
                  type="email"
                  placeholder="Enter your email"
                />
                <Input
                  label="Password"
                  type="password"
                  placeholder="Create a password"
                />
                <Button variant="primary" className="w-full">
                  Create Account
                </Button>
              </div>
            </Card>

            <Card variant="default">
              <h3 className="font-head font-semibold mb-6 text-text-primary">Stream Settings</h3>
              <div className="space-y-4">
                <Input
                  label="Stream Title"
                  placeholder="Enter stream title"
                />
                <Input
                  label="Description"
                  placeholder="Describe your stream"
                />
                <div className="space-y-2">
                  <label className="text-sm font-medium text-text-primary">Quality</label>
                  <Progress value={80} showLabel />
                </div>
                <Button variant="secondary" className="w-full">
                  <Play size={16} className="mr-2" />
                  Start Streaming
                </Button>
              </div>
            </Card>
          </div>
        </section>

        {/* Theme Comparison */}
        <section>
          <h2 className="text-4xl font-head font-bold mb-8 text-gradient">Theme Comparison</h2>
          <Card variant="default">
            <div className="text-center py-8">
              <h3 className="font-head font-semibold text-2xl mb-4 text-text-primary">
                Dynamic Theme System
              </h3>
              <p className="text-text-secondary mb-6 max-w-2xl mx-auto">
                Our theme system uses CSS variables to enable seamless switching between design variations. 
                All components automatically adapt to the selected theme while maintaining consistent behavior and accessibility.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
                <div className="glass-panel p-6 rounded-theme-lg">
                  <h4 className="font-head font-semibold mb-3 text-primary">Default Theme</h4>
                  <ul className="text-sm text-text-secondary space-y-2 text-left">
                    <li>• Cyan & Green color palette</li>
                    <li>• Space Grotesk + Inter fonts</li>
                    <li>• Sharp, modern aesthetics</li>
                    <li>• Gaming-focused design</li>
                  </ul>
                </div>
                <div className="glass-panel p-6 rounded-theme-lg">
                  <h4 className="font-head font-semibold mb-3 text-primary">Alternative Theme</h4>
                  <ul className="text-sm text-text-secondary space-y-2 text-left">
                    <li>• Purple & Pink color palette</li>
                    <li>• Clash Display + Inter fonts</li>
                    <li>• Rounded, friendly aesthetics</li>
                    <li>• Creative-focused design</li>
                  </ul>
                </div>
              </div>
            </div>
          </Card>
        </section>
      </div>
    </div>
  )
}

export default ThemeShowcase
