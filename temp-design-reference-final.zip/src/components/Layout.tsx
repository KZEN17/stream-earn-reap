import React, { useState } from 'react'
import Header from './Header'
import Sidebar from './Sidebar'
import FloatingActionButton from './FloatingActionButton'
import BottomNav from './BottomNav'

interface LayoutProps {
  children: React.ReactNode
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#0B0C0E', color: '#ffffff' }}>
      <Header onMenuClick={() => setSidebarOpen(!sidebarOpen)} />
      
      <div className="flex">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        
        <main className="flex-1 lg:ml-64 pt-16 pb-20 lg:pb-8">
          <div style={{ animation: 'fadeIn 0.3s ease-out' }}>
            {children}
          </div>
        </main>
      </div>
      
      <FloatingActionButton />
      <BottomNav />
    </div>
  )
}

export default Layout
