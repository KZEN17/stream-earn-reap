import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import { 
  Home, 
  Calendar, 
  Trophy, 
  MessageSquare, 
  BarChart3, 
  BookOpen, 
  User,
  X,
  Palette,
  Package,
  Download
} from 'lucide-react'

interface SidebarProps {
  isOpen: boolean
  onClose: () => void
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const location = useLocation()

  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/calendar', icon: Calendar, label: 'Launch Calendar' },
    { path: '/rewards', icon: Trophy, label: 'Rewards' },
    { path: '/raidchat', icon: MessageSquare, label: 'Raid Chat' },
    { path: '/leaderboards', icon: BarChart3, label: 'Leaderboards' },
    { path: '/guide', icon: BookOpen, label: 'Guide' },
    { path: '/profile', icon: User, label: 'Profile' },
    { path: '/brand-book', icon: Palette, label: 'Brand Book' },
    { path: '/ui-kit', icon: Package, label: 'UI Kit' },
    { path: '/media-pack', icon: Download, label: 'Media Pack' },
  ]

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <aside 
        className={`fixed left-0 top-0 h-full w-64 z-50 transform transition-transform duration-300 lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
        style={{
          backgroundColor: 'rgba(11, 12, 14, 0.95)',
          backdropFilter: 'blur(12px)',
          borderRight: '1px solid rgba(255, 255, 255, 0.1)'
        }}
      >
        <div className="flex items-center justify-between p-6 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div 
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{ backgroundColor: '#3CFF88' }}
            >
              <span className="text-black font-bold text-sm">C</span>
            </div>
            <h1 
              className="text-xl font-bold"
              style={{ 
                fontFamily: 'Space Grotesk, sans-serif',
                background: 'linear-gradient(135deg, #3CFF88, #00E0FF)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}
            >
              ClipStream
            </h1>
          </div>
          
          <button
            onClick={onClose}
            className="lg:hidden p-1 rounded-lg transition-colors"
            style={{ color: '#9CA3AF' }}
            onMouseEnter={(e) => e.target.style.color = '#3CFF88'}
            onMouseLeave={(e) => e.target.style.color = '#9CA3AF'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="p-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = location.pathname === item.path
            
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={onClose}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300 ${
                  isActive 
                    ? 'text-white border-r-2' 
                    : 'text-gray-400 hover:text-white'
                }`}
                style={{
                  backgroundColor: isActive ? 'rgba(255, 255, 255, 0.1)' : 'transparent',
                  borderRightColor: isActive ? '#3CFF88' : 'transparent'
                }}
                onMouseEnter={(e) => {
                  if (!isActive) {
                    e.target.style.backgroundColor = 'rgba(255, 255, 255, 0.05)'
                    e.target.style.color = '#3CFF88'
                  }
                }}
                onMouseLeave={(e) => {
                  if (!isActive) {
                    e.target.style.backgroundColor = 'transparent'
                    e.target.style.color = '#9CA3AF'
                  }
                }}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            )
          })}
        </nav>
      </aside>
    </>
  )
}

export default Sidebar
