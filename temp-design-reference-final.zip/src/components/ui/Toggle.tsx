import React from 'react'
import { clsx } from 'clsx'

interface ToggleProps {
  checked: boolean
  onChange: (checked: boolean) => void
  label?: string
  disabled?: boolean
}

const Toggle: React.FC<ToggleProps> = ({
  checked,
  onChange,
  label,
  disabled = false
}) => {
  return (
    <div className="flex items-center space-x-3">
      <button
        type="button"
        className={clsx(
          'relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-300',
          'focus:outline-none focus:ring-2 focus:ring-neon-green/50 focus:ring-offset-2 focus:ring-offset-dark-950',
          checked ? 'bg-gradient-to-r from-neon-green to-neon-cyan' : 'bg-dark-700',
          disabled && 'opacity-50 cursor-not-allowed'
        )}
        onClick={() => !disabled && onChange(!checked)}
        disabled={disabled}
      >
        <span
          className={clsx(
            'inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-300',
            checked ? 'translate-x-6' : 'translate-x-1'
          )}
        />
      </button>
      {label && (
        <span className={clsx(
          'text-sm font-medium',
          disabled ? 'text-gray-500' : 'text-gray-300'
        )}>
          {label}
        </span>
      )}
    </div>
  )
}

export default Toggle
