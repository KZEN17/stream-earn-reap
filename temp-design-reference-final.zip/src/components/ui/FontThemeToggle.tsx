import React, { useState, useEffect } from 'react'
import { Type, Palette } from 'lucide-react'
import { clsx } from 'clsx'

interface FontThemeToggleProps {
  className?: string
}

const FontThemeToggle: React.FC<FontThemeToggleProps> = ({ className }) => {
  const [theme, setTheme] = useState<'default' | 'alt'>('default')
  const [isAnimating, setIsAnimating] = useState(false)

  useEffect(() => {
    // Check for saved theme preference or default to 'default'
    const savedTheme = localStorage.getItem('clip-theme') as 'default' | 'alt' || 'default'
    setTheme(savedTheme)
    document.documentElement.setAttribute('data-theme', savedTheme)
  }, [])

  const toggleTheme = () => {
    if (isAnimating) return
    
    setIsAnimating(true)
    const newTheme = theme === 'default' ? 'alt' : 'default'
    
    // Add transition class to body for smooth theme change
    document.body.style.transition = 'all 0.3s ease'
    
    setTheme(newTheme)
    document.documentElement.setAttribute('data-theme', newTheme)
    localStorage.setItem('clip-theme', newTheme)
    
    // Remove transition after animation completes
    setTimeout(() => {
      document.body.style.transition = ''
      setIsAnimating(false)
    }, 300)
  }

  return (
    <button
      onClick={toggleTheme}
      disabled={isAnimating}
      className={clsx(
        'group relative overflow-hidden rounded-xl p-4 transition-all duration-300',
        'bg-gradient-to-br from-primary/10 via-accent/10 to-accent-secondary/10',
        'border border-primary/20 hover:border-primary/40',
        'shadow-theme-neon-sm hover:shadow-theme-neon-md',
        'hover:scale-105 active:scale-95',
        'focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2 focus:ring-offset-bg-primary',
        'disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100',
        className
      )}
      title={`Switch to ${theme === 'default' ? 'Clash Display' : 'Space Grotesk'} font theme`}
    >
      {/* Animated background glow */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-accent/20 to-accent-secondary/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      {/* Neon border glow effect */}
      <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-primary via-accent to-accent-secondary opacity-0 group-hover:opacity-20 blur-sm transition-opacity duration-300" />
      
      {/* Content container */}
      <div className="relative flex flex-col items-center gap-2 min-w-[80px]">
        {/* Icon with rotation animation */}
        <div className="relative w-6 h-6">
          <Type 
            size={24} 
            className={clsx(
              'absolute inset-0 text-primary transition-all duration-500',
              'drop-shadow-sm group-hover:drop-shadow-md',
              isAnimating && 'animate-spin'
            )}
            style={{ 
              filter: `drop-shadow(0 0 6px var(--color-primary))`,
              transform: theme === 'alt' ? 'rotate(180deg)' : 'rotate(0deg)'
            }}
          />
        </div>
        
        {/* Font name indicator */}
        <div className="text-xs font-medium text-center leading-tight">
          <div className={clsx(
            'transition-all duration-300',
            theme === 'default' ? 'text-primary' : 'text-text-tertiary'
          )}>
            Space
          </div>
          <div className={clsx(
            'transition-all duration-300',
            theme === 'alt' ? 'text-primary' : 'text-text-tertiary'
          )}>
            Clash
          </div>
        </div>
      </div>
      
      {/* Ripple effect for animation feedback */}
      {isAnimating && (
        <div className="absolute inset-0 bg-gradient-to-r from-primary/30 via-accent/30 to-accent-secondary/30 animate-ping rounded-xl" />
      )}
      
      {/* Subtle pulse animation when active */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-accent/5 to-accent-secondary/5 animate-pulse rounded-xl opacity-50" />
    </button>
  )
}

export default FontThemeToggle
