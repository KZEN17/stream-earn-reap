import React from 'react'
import { clsx } from 'clsx'

interface SliderProps {
  value: number
  onChange: (value: number) => void
  min?: number
  max?: number
  step?: number
  label?: string
  showValue?: boolean
  disabled?: boolean
  className?: string
}

const Slider: React.FC<SliderProps> = ({
  value,
  onChange,
  min = 0,
  max = 100,
  step = 1,
  label,
  showValue = false,
  disabled = false,
  className
}) => {
  const percentage = ((value - min) / (max - min)) * 100

  return (
    <div className={clsx('space-y-2', className)}>
      {(label || showValue) && (
        <div className="flex justify-between text-sm">
          {label && <span className="text-gray-300">{label}</span>}
          {showValue && <span className="text-gray-300">{value}</span>}
        </div>
      )}
      
      <div className="relative">
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          disabled={disabled}
          className={clsx(
            'w-full h-2 bg-dark-800 rounded-lg appearance-none cursor-pointer',
            'focus:outline-none focus:ring-2 focus:ring-neon-green/50',
            'slider-thumb',
            disabled && 'opacity-50 cursor-not-allowed'
          )}
          style={{
            background: `linear-gradient(to right, #3CFF88 0%, #00CFFF ${percentage}%, #212529 ${percentage}%, #212529 100%)`
          }}
        />
      </div>
    </div>
  )
}

export default Slider
