import React from 'react'
import { clsx } from 'clsx'

interface AvatarProps {
  src?: string
  alt?: string
  size?: 'sm' | 'md' | 'lg' | 'xl'
  isLive?: boolean
  className?: string
  fallback?: string
}

const Avatar: React.FC<AvatarProps> = ({
  src,
  alt,
  size = 'md',
  isLive = false,
  className,
  fallback
}) => {
  const sizes = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24'
  }

  const ringSize = {
    sm: 'ring-2',
    md: 'ring-2',
    lg: 'ring-4',
    xl: 'ring-4'
  }

  return (
    <div className={clsx('relative inline-block', className)}>
      <div
        className={clsx(
          'rounded-full overflow-hidden',
          sizes[size],
          isLive && `${ringSize[size]} ring-neon-green animate-pulse-neon`
        )}
      >
        {src ? (
          <img
            src={src}
            alt={alt}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-neon-magenta to-neon-cyan flex items-center justify-center">
            <span className="text-white font-bold text-sm">
              {fallback || alt?.charAt(0)?.toUpperCase() || '?'}
            </span>
          </div>
        )}
      </div>
      
      {isLive && (
        <div className="absolute -bottom-1 -right-1 bg-neon-green text-dark-950 text-xs font-bold px-2 py-1 rounded-full animate-pulse">
          LIVE
        </div>
      )}
    </div>
  )
}

export default Avatar
