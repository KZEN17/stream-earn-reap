import React from 'react'
import { Check } from 'lucide-react'
import { clsx } from 'clsx'

interface CheckboxProps {
  checked: boolean
  onChange: (checked: boolean) => void
  label?: string
  disabled?: boolean
  className?: string
}

const Checkbox: React.FC<CheckboxProps> = ({
  checked,
  onChange,
  label,
  disabled = false,
  className
}) => {
  return (
    <div className={clsx('flex items-center space-x-3', className)}>
      <button
        type="button"
        className={clsx(
          'w-5 h-5 rounded border-2 flex items-center justify-center transition-all duration-200',
          'focus:outline-none focus:ring-2 focus:ring-neon-green/50 focus:ring-offset-2 focus:ring-offset-dark-950',
          checked
            ? 'bg-gradient-to-r from-neon-green to-neon-cyan border-transparent'
            : 'border-gray-400 hover:border-gray-300',
          disabled && 'opacity-50 cursor-not-allowed'
        )}
        onClick={() => !disabled && onChange(!checked)}
        disabled={disabled}
      >
        {checked && (
          <Check size={14} className="text-white" />
        )}
      </button>
      
      {label && (
        <span
          className={clsx(
            'text-sm font-medium cursor-pointer',
            disabled ? 'text-gray-500' : 'text-gray-300'
          )}
          onClick={() => !disabled && onChange(!checked)}
        >
          {label}
        </span>
      )}
    </div>
  )
}

export default Checkbox
