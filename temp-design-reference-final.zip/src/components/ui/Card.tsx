import React from 'react'
import { clsx } from 'clsx'

interface CardProps {
  variant?: 'default' | 'campaign' | 'profile' | 'leaderboard'
  className?: string
  children: React.ReactNode
  onClick?: () => void
}

const Card: React.FC<CardProps> = ({
  variant = 'default',
  className,
  children,
  onClick
}) => {
  const baseClasses = 'glass-panel transition-all duration-300'
  
  const variants = {
    default: 'p-6 hover:bg-glass-medium',
    campaign: 'p-6 border-l-4 border-primary hover:bg-glass-medium hover:border-primary/70',
    profile: 'p-6 hover:bg-glass-medium hover:scale-105 transform',
    leaderboard: 'p-4 mb-3 hover:bg-glass-medium hover:border-primary/30'
  }

  const Component = onClick ? 'button' : 'div'

  return (
    <Component
      className={clsx(
        baseClasses,
        variants[variant],
        onClick && 'cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary/50',
        className
      )}
      onClick={onClick}
    >
      {children}
    </Component>
  )
}

export default Card
