import React from 'react'
import { clsx } from 'clsx'

interface TableColumn {
  key: string
  label: string
  sortable?: boolean
  render?: (value: any, row: any) => React.ReactNode
}

interface TableProps {
  columns: TableColumn[]
  data: any[]
  zebra?: boolean
  className?: string
}

const Table: React.FC<TableProps> = ({
  columns,
  data,
  zebra = true,
  className
}) => {
  return (
    <div className={clsx('glass-panel rounded-lg overflow-hidden', className)}>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-dark-800 border-b border-white/10">
            <tr>
              {columns.map((column) => (
                <th
                  key={column.key}
                  className="px-6 py-4 text-left text-sm font-semibold text-gray-300 uppercase tracking-wider"
                >
                  {column.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {data.map((row, index) => (
              <tr
                key={index}
                className={clsx(
                  'hover:bg-glass-light transition-colors',
                  zebra && index % 2 === 1 && 'bg-dark-800/30'
                )}
              >
                {columns.map((column) => (
                  <td key={column.key} className="px-6 py-4 text-sm text-white">
                    {column.render
                      ? column.render(row[column.key], row)
                      : row[column.key]
                    }
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default Table
