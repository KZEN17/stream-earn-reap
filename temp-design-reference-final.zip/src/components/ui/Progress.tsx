import React from 'react'
import { clsx } from 'clsx'

interface ProgressProps {
  value: number
  max?: number
  variant?: 'linear' | 'circular'
  size?: 'sm' | 'md' | 'lg'
  showLabel?: boolean
  label?: string
  className?: string
}

const Progress: React.FC<ProgressProps> = ({
  value,
  max = 100,
  variant = 'linear',
  size = 'md',
  showLabel = false,
  label,
  className
}) => {
  const percentage = Math.min((value / max) * 100, 100)

  if (variant === 'circular') {
    const sizes = {
      sm: { size: 16, strokeWidth: 2, radius: 6 },
      md: { size: 24, strokeWidth: 3, radius: 9 },
      lg: { size: 32, strokeWidth: 4, radius: 12 }
    }
    
    const { size: circleSize, strokeWidth, radius } = sizes[size]
    const circumference = 2 * Math.PI * radius
    const strokeDashoffset = circumference - (percentage / 100) * circumference

    return (
      <div className={clsx('relative inline-flex items-center justify-center', className)}>
        <svg
          className={`transform -rotate-90`}
          width={circleSize * 4}
          height={circleSize * 4}
          viewBox={`0 0 ${circleSize * 4} ${circleSize * 4}`}
        >
          <circle
            cx={circleSize * 2}
            cy={circleSize * 2}
            r={radius}
            stroke="currentColor"
            strokeWidth={strokeWidth}
            fill="transparent"
            className="text-dark-800"
          />
          <circle
            cx={circleSize * 2}
            cy={circleSize * 2}
            r={radius}
            stroke="url(#progress-gradient)"
            strokeWidth={strokeWidth}
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            className="transition-all duration-500"
            strokeLinecap="round"
          />
          <defs>
            <linearGradient id="progress-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3CFF88" />
              <stop offset="100%" stopColor="#00CFFF" />
            </linearGradient>
          </defs>
        </svg>
        {showLabel && (
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-sm font-semibold">{Math.round(percentage)}%</span>
          </div>
        )}
      </div>
    )
  }

  const heights = {
    sm: 'h-1',
    md: 'h-2',
    lg: 'h-3'
  }

  return (
    <div className={clsx('space-y-2', className)}>
      {(showLabel || label) && (
        <div className="flex justify-between text-sm">
          <span className="text-gray-300">{label}</span>
          {showLabel && <span className="text-gray-300">{Math.round(percentage)}%</span>}
        </div>
      )}
      <div className={clsx('bg-dark-800 rounded-full overflow-hidden', heights[size])}>
        <div
          className="h-full bg-gradient-to-r from-neon-green to-neon-cyan transition-all duration-500"
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  )
}

export default Progress
