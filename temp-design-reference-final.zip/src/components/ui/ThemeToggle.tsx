import React, { useState, useEffect } from 'react'
import { Palette, Sun, Moon } from 'lucide-react'
import { clsx } from 'clsx'

interface ThemeToggleProps {
  className?: string
}

const ThemeToggle: React.FC<ThemeToggleProps> = ({ className }) => {
  const [theme, setTheme] = useState<'default' | 'alt'>('default')
  const [isAnimating, setIsAnimating] = useState(false)

  useEffect(() => {
    // Check for saved theme preference or default to 'default'
    const savedTheme = localStorage.getItem('clip-theme') as 'default' | 'alt' || 'default'
    setTheme(savedTheme)
    document.documentElement.setAttribute('data-theme', savedTheme)
  }, [])

  const toggleTheme = () => {
    if (isAnimating) return
    
    setIsAnimating(true)
    const newTheme = theme === 'default' ? 'alt' : 'default'
    
    // Add transition class to body for smooth theme change
    document.body.style.transition = 'all 0.3s ease'
    
    setTheme(newTheme)
    document.documentElement.setAttribute('data-theme', newTheme)
    localStorage.setItem('clip-theme', newTheme)
    
    // Remove transition after animation completes
    setTimeout(() => {
      document.body.style.transition = ''
      setIsAnimating(false)
    }, 300)
  }

  return (
    <button
      onClick={toggleTheme}
      disabled={isAnimating}
      className={clsx(
        'relative overflow-hidden rounded-xl p-3 transition-all duration-300',
        'bg-gradient-to-r from-primary/20 via-accent/20 to-accent-secondary/20',
        'border border-primary/30 hover:border-primary/50',
        'shadow-theme-neon-sm hover:shadow-theme-neon-md',
        'hover:scale-105 active:scale-95',
        'focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2 focus:ring-offset-bg-primary',
        'disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100',
        className
      )}
      title={`Switch to ${theme === 'default' ? 'Purple' : 'Cyan'} theme`}
    >
      {/* Background glow effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-accent/10 to-accent-secondary/10 opacity-0 hover:opacity-100 transition-opacity duration-300" />
      
      {/* Icon container */}
      <div className="relative flex items-center justify-center w-6 h-6">
        {/* Default theme icon (Cyan/Green) */}
        <div
          className={clsx(
            'absolute inset-0 flex items-center justify-center transition-all duration-300',
            theme === 'default' 
              ? 'opacity-100 rotate-0 scale-100' 
              : 'opacity-0 rotate-180 scale-50'
          )}
        >
          <Sun 
            size={20} 
            className="text-primary drop-shadow-sm"
            style={{ filter: 'drop-shadow(0 0 4px var(--color-primary))' }}
          />
        </div>
        
        {/* Alt theme icon (Purple/Pink) */}
        <div
          className={clsx(
            'absolute inset-0 flex items-center justify-center transition-all duration-300',
            theme === 'alt' 
              ? 'opacity-100 rotate-0 scale-100' 
              : 'opacity-0 -rotate-180 scale-50'
          )}
        >
          <Moon 
            size={20} 
            className="text-primary drop-shadow-sm"
            style={{ filter: 'drop-shadow(0 0 4px var(--color-primary))' }}
          />
        </div>
      </div>
      
      {/* Ripple effect */}
      {isAnimating && (
        <div className="absolute inset-0 bg-primary/20 animate-ping rounded-xl" />
      )}
    </button>
  )
}

export default ThemeToggle
