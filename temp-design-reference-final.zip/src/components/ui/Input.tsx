import React from 'react'
import { clsx } from 'clsx'

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
  icon?: React.ReactNode
}

const Input: React.FC<InputProps> = ({
  label,
  error,
  icon,
  className,
  ...props
}) => {
  return (
    <div className="space-y-2">
      {label && (
        <label className="block text-sm font-medium text-gray-300">
          {label}
        </label>
      )}
      <div className="relative">
        {icon && (
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
            {icon}
          </div>
        )}
        <input
          className={clsx(
            'w-full bg-dark-800 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-400',
            'focus:outline-none focus:ring-2 focus:ring-neon-green/50 focus:border-neon-green/50',
            'transition-all duration-300',
            icon && 'pl-10',
            error && 'border-red-500 focus:ring-red-500/50 focus:border-red-500/50',
            className
          )}
          {...props}
        />
      </div>
      {error && (
        <p className="text-sm text-red-400">{error}</p>
      )}
    </div>
  )
}

export default Input
