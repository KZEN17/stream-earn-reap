import React from 'react'
import { motion } from 'framer-motion'
import { LucideIcon } from 'lucide-react'

interface MetricCardProps {
  title: string
  value: string
  change: string
  icon: LucideIcon
  color: string
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, change, icon: Icon, color }) => {
  const getColor = (colorName: string) => {
    switch (colorName) {
      case 'neon-green': return '#3CFF88'
      case 'neon-cyan': return '#00E0FF'
      case 'neon-magenta': return '#FF1B8D'
      default: return '#3CFF88'
    }
  }

  const iconColor = getColor(color)

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -2 }}
      className="p-6 rounded-lg transition-all duration-300 group cursor-pointer"
      style={{
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        backdropFilter: 'blur(12px)',
        border: '1px solid rgba(255, 255, 255, 0.1)'
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)'
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.05)'
      }}
    >
      <div className="flex items-center justify-between mb-4">
        <div 
          className="p-3 rounded-lg"
          style={{ backgroundColor: `${iconColor}20` }}
        >
          <Icon className="w-6 h-6" style={{ color: iconColor }} />
        </div>
        <span 
          className="text-sm font-medium px-2 py-1 rounded-full"
          style={{ 
            backgroundColor: change.startsWith('+') ? 'rgba(34, 197, 94, 0.2)' : 'rgba(239, 68, 68, 0.2)',
            color: change.startsWith('+') ? '#22C55E' : '#EF4444'
          }}
        >
          {change}
        </span>
      </div>
      
      <div>
        <div className="text-2xl font-bold mb-1" style={{ color: iconColor }}>
          {value}
        </div>
        <div className="text-sm" style={{ color: '#9CA3AF' }}>
          {title}
        </div>
      </div>
    </motion.div>
  )
}

export default MetricCard
