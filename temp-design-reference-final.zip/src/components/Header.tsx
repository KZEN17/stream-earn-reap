import React from 'react'
import { Menu, Bell, Search, User } from 'lucide-react'
import ThemeToggle from './ui/ThemeToggle'

interface HeaderProps {
  onMenuClick: () => void
}

const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 px-4 py-3 lg:px-6 glass-panel border-b border-white/10">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={onMenuClick}
            className="lg:hidden p-2 rounded-theme-lg transition-colors text-text-secondary hover:text-primary"
          >
            <Menu className="w-6 h-6" />
          </button>
          
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-theme-lg flex items-center justify-center bg-primary">
              <span className="text-black font-bold text-sm">C</span>
            </div>
            <h1 className="text-xl font-head font-bold hidden sm:block text-gradient">
              ClipStream
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-2 px-4 py-2 rounded-theme-lg glass-panel">
            <Search className="w-4 h-4 text-text-tertiary" />
            <input
              type="text"
              placeholder="Search streams, clips..."
              className="bg-transparent border-none outline-none text-text-primary placeholder-text-tertiary w-64"
            />
          </div>
          
          <ThemeToggle />
          
          <button className="p-2 rounded-theme-lg transition-colors relative text-text-secondary hover:text-primary">
            <Bell className="w-5 h-5" />
            <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-red-500" />
          </button>
          
          <button className="p-2 rounded-theme-lg transition-colors text-text-secondary hover:text-primary">
            <User className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  )
}

export default Header
