import React, { useState } from 'react'
import { Copy, Check } from 'lucide-react'

const ColorPalette: React.FC = () => {
  const [copiedColor, setCopiedColor] = useState<string | null>(null)

  const copyToClipboard = (text: string, colorName: string) => {
    navigator.clipboard.writeText(text)
    setCopiedColor(colorName)
    setTimeout(() => setCopiedColor(null), 2000)
  }

  const colors = {
    primary: [
      { name: 'Dark Base', value: '#0B0C0E', description: 'Primary background' },
      { name: 'Dark Secondary', value: '#212529', description: 'Secondary surfaces' },
      { name: 'Dark Tertiary', value: '#343A40', description: 'Tertiary surfaces' }
    ],
    neon: [
      { name: 'Neon Pink', value: '#FF1B8D', description: 'Primary accent' },
      { name: 'Neon Purple', value: '#8B5FFF', description: 'Secondary accent' },
      { name: 'Neon Cyan', value: '#00CFFF', description: 'Info & highlights' },
      { name: 'Neon Green', value: '#3CFF88', description: 'Success & earnings' },
      { name: 'Neon Yellow', value: '#E5FF00', description: 'Warnings & alerts' }
    ]
  }

  return (
    <div className="space-y-8">
      {/* Primary Colors */}
      <div>
        <h3 className="text-xl font-semibold mb-4 text-white">Primary Colors</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {colors.primary.map((color, index) => (
            <div key={index} className="glass-panel p-4">
              <div 
                className="w-full h-20 rounded-lg mb-3 border border-white/10"
                style={{ backgroundColor: color.value }}
              ></div>
              <h4 className="font-semibold text-sm text-white">{color.name}</h4>
              <p className="text-xs text-gray-400 mb-2">{color.description}</p>
              <button
                onClick={() => copyToClipboard(color.value, `primary-${index}`)}
                className="flex items-center gap-1 text-xs text-neon-green hover:text-neon-cyan transition-colors"
              >
                {copiedColor === `primary-${index}` ? <Check size={12} /> : <Copy size={12} />}
                {color.value}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Neon Accents */}
      <div>
        <h3 className="text-xl font-semibold mb-4 text-white">Neon Accents</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {colors.neon.map((color, index) => (
            <div key={index} className="glass-panel p-4">
              <div 
                className="w-full h-20 rounded-lg mb-3 border border-white/10"
                style={{ 
                  backgroundColor: color.value,
                  boxShadow: `0 0 20px ${color.value}40`
                }}
              ></div>
              <h4 className="font-semibold text-sm text-white">{color.name}</h4>
              <p className="text-xs text-gray-400 mb-2">{color.description}</p>
              <button
                onClick={() => copyToClipboard(color.value, `neon-${index}`)}
                className="flex items-center gap-1 text-xs text-neon-green hover:text-neon-cyan transition-colors"
              >
                {copiedColor === `neon-${index}` ? <Check size={12} /> : <Copy size={12} />}
                {color.value}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default ColorPalette
