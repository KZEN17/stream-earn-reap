import React from 'react'
import { clsx } from 'clsx'

interface LogoProps {
  variant?: 'full' | 'icon' | 'monochrome'
  size?: 'sm' | 'md' | 'lg' | 'xl'
  className?: string
}

const Logo: React.FC<LogoProps> = ({
  variant = 'full',
  size = 'md',
  className
}) => {
  const sizes = {
    sm: { icon: 'w-6 h-6', text: 'text-lg', gap: 'gap-2' },
    md: { icon: 'w-8 h-8', text: 'text-2xl', gap: 'gap-2' },
    lg: { icon: 'w-12 h-12', text: 'text-4xl', gap: 'gap-3' },
    xl: { icon: 'w-16 h-16', text: 'text-6xl', gap: 'gap-4' }
  }

  const { icon: iconSize, text: textSize, gap } = sizes[size]

  if (variant === 'icon') {
    return (
      <div className={clsx(iconSize, className)}>
        <div className={clsx(
          'w-full h-full rounded-lg flex items-center justify-center font-black text-white',
          variant === 'monochrome' ? 'bg-white text-black' : 'bg-gradient-to-br from-neon-magenta to-neon-cyan'
        )}>
          <span className={size === 'sm' ? 'text-sm' : size === 'md' ? 'text-lg' : size === 'lg' ? 'text-2xl' : 'text-4xl'}>
            C
          </span>
        </div>
      </div>
    )
  }

  return (
    <div className={clsx('inline-flex items-center font-bold', gap, className)}>
      <div className={clsx(
        iconSize,
        'rounded-lg flex items-center justify-center font-black text-white',
        variant === 'monochrome' ? 'bg-white text-black' : 'bg-gradient-to-br from-neon-magenta to-neon-cyan'
      )}>
        <span className={size === 'sm' ? 'text-sm' : size === 'md' ? 'text-lg' : size === 'lg' ? 'text-2xl' : 'text-4xl'}>
          C
        </span>
      </div>
      <span className={clsx(
        textSize,
        variant === 'monochrome' ? 'text-white' : 'text-gradient'
      )}>
        CLIP
      </span>
    </div>
  )
}

export default Logo
