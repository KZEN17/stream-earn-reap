import React from 'react'
import Logo from './Logo'

const SocialBanners: React.FC = () => {
  const banners = [
    {
      name: 'Twitter/X Header',
      dimensions: '1500x500px',
      aspectRatio: 'aspect-[3/1]',
      gradient: 'from-neon-magenta/20 via-neon-purple/20 to-neon-cyan/20'
    },
    {
      name: 'Discord Banner',
      dimensions: '960x540px',
      aspectRatio: 'aspect-[16/9]',
      gradient: 'from-neon-purple/20 to-neon-magenta/20'
    },
    {
      name: 'YouTube Channel Art',
      dimensions: '2560x1440px',
      aspectRatio: 'aspect-[16/9]',
      gradient: 'from-neon-cyan/20 via-neon-green/20 to-neon-yellow/20'
    },
    {
      name: 'Twitch Offline Banner',
      dimensions: '1920x1080px',
      aspectRatio: 'aspect-[16/9]',
      gradient: 'from-neon-green/20 to-neon-cyan/20'
    },
    {
      name: 'LinkedIn Company Cover',
      dimensions: '1128x191px',
      aspectRatio: 'aspect-[6/1]',
      gradient: 'from-neon-purple/20 via-neon-cyan/20 to-neon-green/20'
    }
  ]

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {banners.map((banner, index) => (
          <div key={index} className="glass-panel p-4">
            <h4 className="font-semibold mb-4 text-white">{banner.name}</h4>
            <div className={`${banner.aspectRatio} bg-gradient-to-r ${banner.gradient} rounded-lg flex items-center justify-center border border-white/10 mb-3`}>
              <div className="text-center">
                <Logo size="lg" className="mb-4" />
                <p className="text-gray-300 text-lg">Stream • Clip • Earn $</p>
              </div>
            </div>
            <p className="text-xs text-gray-400">{banner.dimensions}</p>
          </div>
        ))}
      </div>

      {/* Profile Icons */}
      <div className="glass-panel p-6">
        <h4 className="font-semibold mb-4 text-white">Profile Icons</h4>
        <div className="flex justify-center gap-8">
          <div className="text-center">
            <Logo variant="icon" size="xl" className="mb-2 mx-auto" />
            <p className="text-sm text-gray-400">Circular</p>
            <p className="text-xs text-gray-500">512x512px</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-neon-magenta to-neon-cyan rounded-lg flex items-center justify-center mb-2 mx-auto">
              <span className="text-white font-black text-4xl">C</span>
            </div>
            <p className="text-sm text-gray-400">Square</p>
            <p className="text-xs text-gray-500">512x512px</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SocialBanners
