import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Home, Calendar, Trophy, MessageSquare, User } from 'lucide-react'

const BottomNav: React.FC = () => {
  const location = useLocation()

  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/calendar', icon: Calendar, label: 'Calendar' },
    { path: '/rewards', icon: Trophy, label: 'Rewards' },
    { path: '/raidchat', icon: MessageSquare, label: 'Chat' },
    { path: '/profile', icon: User, label: 'Profile' },
  ]

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 lg:hidden z-30 px-4 py-2"
      style={{
        backgroundColor: 'rgba(11, 12, 14, 0.95)',
        backdropFilter: 'blur(12px)',
        borderTop: '1px solid rgba(255, 255, 255, 0.1)'
      }}
    >
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = location.pathname === item.path
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className="flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-all duration-300"
              style={{
                color: isActive ? '#3CFF88' : '#6B7280'
              }}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs font-medium">{item.label}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}

export default BottomNav
