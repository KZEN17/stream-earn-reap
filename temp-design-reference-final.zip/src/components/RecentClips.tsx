import React from 'react'
import { motion } from 'framer-motion'
import { Play, Eye, Heart, Share } from 'lucide-react'

const RecentClips: React.FC = () => {
  const clips = [
    {
      id: 1,
      title: 'Amazing Headshot!',
      creator: 'ProGamer123',
      views: '45.2K',
      likes: '2.1K',
      duration: '0:15',
      thumbnail: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=300&h=200&fit=crop',
      earnings: '$12.50'
    },
    {
      id: 2,
      title: 'Epic Beat Drop',
      creator: 'BeatMaker',
      views: '32.8K',
      likes: '1.8K',
      duration: '0:30',
      thumbnail: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=200&fit=crop',
      earnings: '$8.75'
    },
    {
      id: 3,
      title: 'Perfect Flip!',
      creator: 'ChefMike',
      views: '28.5K',
      likes: '1.5K',
      duration: '0:12',
      thumbnail: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop',
      earnings: '$6.25'
    }
  ]

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 
          className="text-2xl font-bold"
          style={{ 
            fontFamily: 'Space Grotesk, sans-serif',
            color: '#00E0FF',
            textShadow: '0 0 10px rgba(0, 224, 255, 0.5)'
          }}
        >
          Recent Clips
        </h2>
        <button 
          className="text-sm font-medium transition-colors"
          style={{ color: '#FF1B8D' }}
          onMouseEnter={(e) => e.target.style.color = '#00E0FF'}
          onMouseLeave={(e) => e.target.style.color = '#FF1B8D'}
        >
          View All
        </button>
      </div>

      <div className="space-y-4">
        {clips.map((clip, index) => (
          <motion.div
            key={clip.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-4 rounded-lg transition-all duration-300 cursor-pointer"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.05)',
              backdropFilter: 'blur(12px)',
              border: '1px solid rgba(255, 255, 255, 0.1)'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)'
              e.currentTarget.style.borderColor = 'rgba(0, 224, 255, 0.5)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.05)'
              e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)'
            }}
          >
            <div className="flex gap-4">
              <div className="relative">
                <img
                  src={clip.thumbnail}
                  alt={clip.title}
                  className="w-20 h-14 object-cover rounded-lg"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div 
                    className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: 'rgba(0, 0, 0, 0.7)' }}
                  >
                    <Play className="w-4 h-4 text-white" />
                  </div>
                </div>
                <div 
                  className="absolute bottom-1 right-1 px-1 py-0.5 rounded text-xs font-medium"
                  style={{ backgroundColor: 'rgba(0, 0, 0, 0.8)', color: 'white' }}
                >
                  {clip.duration}
                </div>
              </div>
              
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-white truncate mb-1">
                  {clip.title}
                </h3>
                <p className="text-sm mb-2" style={{ color: '#9CA3AF' }}>
                  {clip.creator}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 text-xs" style={{ color: '#6B7280' }}>
                    <div className="flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      <span>{clip.views}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className="w-3 h-3" />
                      <span>{clip.likes}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span 
                      className="text-sm font-bold"
                      style={{ color: '#3CFF88' }}
                    >
                      {clip.earnings}
                    </span>
                    <button 
                      className="p-1 rounded transition-colors"
                      style={{ color: '#6B7280' }}
                      onMouseEnter={(e) => e.target.style.color = '#00E0FF'}
                      onMouseLeave={(e) => e.target.style.color = '#6B7280'}
                    >
                      <Share className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

export default RecentClips
