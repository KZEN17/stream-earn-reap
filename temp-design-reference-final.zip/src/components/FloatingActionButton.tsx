import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus, Scissors, Video, Upload } from 'lucide-react'

const FloatingActionButton: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false)

  const actions = [
    { icon: Scissors, label: 'Create Clip', color: '#3CFF88' },
    { icon: Video, label: 'Start Stream', color: '#00E0FF' },
    { icon: Upload, label: 'Upload Video', color: '#FF1B8D' },
  ]

  return (
    <div className="fixed bottom-24 right-6 lg:bottom-8 z-40">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="absolute bottom-16 right-0 space-y-3"
          >
            {actions.map((action, index) => {
              const Icon = action.icon
              return (
                <motion.button
                  key={action.label}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg shadow-lg transition-all duration-300"
                  style={{
                    backgroundColor: 'rgba(11, 12, 14, 0.95)',
                    backdropFilter: 'blur(12px)',
                    border: `1px solid ${action.color}30`,
                    color: action.color
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.backgroundColor = `${action.color}20`
                    e.target.style.borderColor = action.color
                    e.target.style.boxShadow = `0 0 10px ${action.color}30`
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.backgroundColor = 'rgba(11, 12, 14, 0.95)'
                    e.target.style.borderColor = `${action.color}30`
                    e.target.style.boxShadow = 'none'
                  }}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium whitespace-nowrap">{action.label}</span>
                </motion.button>
              )
            })}
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 rounded-full shadow-lg transition-all duration-300"
        style={{
          backgroundColor: '#3CFF88',
          color: '#000000'
        }}
        onMouseEnter={(e) => {
          e.target.style.boxShadow = '0 0 20px rgba(60, 255, 136, 0.5)'
        }}
        onMouseLeave={(e) => {
          e.target.style.boxShadow = 'none'
        }}
      >
        <motion.div
          animate={{ rotate: isOpen ? 45 : 0 }}
          transition={{ duration: 0.2 }}
        >
          <Plus className="w-6 h-6 mx-auto" />
        </motion.div>
      </motion.button>
    </div>
  )
}

export default FloatingActionButton
