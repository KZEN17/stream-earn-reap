/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        'head': 'var(--font-heading)',
        'body': 'var(--font-body)',
        'space': ['Space Grotesk', 'sans-serif'],
        'inter': ['Inter', 'sans-serif'],
        'clash': ['Clash Display', 'Space Grotesk', 'sans-serif'],
      },
      colors: {
        // CSS Variable-based colors
        'bg': {
          primary: 'var(--color-bg-primary)',
          secondary: 'var(--color-bg-secondary)',
          tertiary: 'var(--color-bg-tertiary)',
        },
        'text': {
          primary: 'var(--color-text-primary)',
          secondary: 'var(--color-text-secondary)',
          tertiary: 'var(--color-text-tertiary)',
        },
        'primary': 'var(--color-primary)',
        'accent': 'var(--color-accent)',
        'accent-secondary': 'var(--color-accent-secondary)',
        'glass': {
          light: 'var(--color-glass-light)',
          medium: 'var(--color-glass-medium)',
          dark: 'var(--color-glass-dark)',
        },
        // Legacy colors for backward compatibility
        dark: {
          50: '#F8F9FA',
          100: '#E9ECEF',
          200: '#DEE2E6',
          300: '#CED4DA',
          400: '#ADB5BD',
          500: '#6C757D',
          600: '#495057',
          700: '#343A40',
          800: '#212529',
          900: '#0D0D0F',
          950: '#0B0C0E',
        },
        neon: {
          green: '#3CFF88',
          cyan: '#00E0FF',
          magenta: '#FF1B8D',
          purple: '#8B5CF6',
          yellow: '#FDE047',
        },
      },
      borderRadius: {
        'theme-sm': 'var(--radius-sm)',
        'theme-md': 'var(--radius-md)',
        'theme-lg': 'var(--radius-lg)',
        'theme-xl': 'var(--radius-xl)',
      },
      boxShadow: {
        'theme-neon-sm': 'var(--shadow-neon-sm)',
        'theme-neon-md': 'var(--shadow-neon-md)',
        'theme-neon-lg': 'var(--shadow-neon-lg)',
        'theme-glass': 'var(--shadow-glass)',
        // Legacy shadows
        'neon-sm': '0 0 10px rgba(60, 255, 136, 0.3)',
        'neon-md': '0 0 20px rgba(60, 255, 136, 0.4)',
        'neon-lg': '0 0 30px rgba(60, 255, 136, 0.5)',
        'neon-cyan': '0 0 20px rgba(0, 224, 255, 0.4)',
        'neon-magenta': '0 0 20px rgba(255, 27, 141, 0.4)',
        'glass': '0 8px 32px 0 rgba(31, 38, 135, 0.37)',
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic': 'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
        'neon-glow': 'linear-gradient(135deg, rgba(60, 255, 136, 0.1) 0%, rgba(0, 224, 255, 0.1) 50%, rgba(255, 27, 141, 0.1) 100%)',
        'theme-gradient': 'var(--bg-gradient-primary)',
      },
      animation: {
        'pulse-neon': 'pulse-neon 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
        'float': 'float 3s ease-in-out infinite',
        'slide-up': 'slide-up 0.5s ease-out',
        'fade-in': 'fade-in 0.3s ease-out',
      },
      keyframes: {
        'pulse-neon': {
          '0%, 100%': {
            opacity: '1',
            boxShadow: 'var(--shadow-neon-md)',
          },
          '50%': {
            opacity: '0.8',
            boxShadow: 'var(--shadow-neon-lg)',
          },
        },
        'glow': {
          'from': {
            boxShadow: 'var(--shadow-neon-md)',
          },
          'to': {
            boxShadow: 'var(--shadow-neon-lg)',
          },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        'slide-up': {
          'from': {
            opacity: '0',
            transform: 'translateY(20px)',
          },
          'to': {
            opacity: '1',
            transform: 'translateY(0)',
          },
        },
        'fade-in': {
          'from': { opacity: '0' },
          'to': { opacity: '1' },
        },
      },
    },
  },
  plugins: [],
}
