# CLIP Platform - Dynamic Theme System

A modern streaming platform with a complete dynamic theme system built with React, TypeScript, and Tailwind CSS.

## 🎨 Theme System Features

### Dual Theme Support
- **Default Theme**: Cyan/Green palette with Space Grotesk + Inter fonts
- **Alternative Theme**: Purple/Pink palette with Clash Display + Inter fonts

### CSS Variable Architecture
- Centralized color tokens for consistent theming
- Dynamic font family switching
- Responsive radius and shadow systems
- Smooth theme transitions

### Component Variations
All UI components automatically adapt to the selected theme:
- Buttons (Primary, Secondary, Tertiary, Ghost)
- Cards (Default, Campaign, Profile, Leaderboard)
- Navigation elements
- Form inputs and controls
- Progress indicators
- Avatars and media components

## 🚀 Getting Started

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## 🎯 Theme Toggle Usage

The `ThemeToggle` component provides seamless switching between themes:

```tsx
import ThemeToggle from './components/ui/ThemeToggle'

// Use in your header or navigation
<ThemeToggle />
```

## 🎨 CSS Variables

### Default Theme
```css
:root[data-theme="default"] {
  --color-primary: #3CFF88;
  --color-accent: #00E0FF;
  --color-accent-secondary: #FF1B8D;
  --font-heading: 'Space Grotesk', sans-serif;
  --font-body: 'Inter', sans-serif;
}
```

### Alternative Theme
```css
:root[data-theme="alt"] {
  --color-primary: #8B5CF6;
  --color-accent: #EC4899;
  --color-accent-secondary: #F59E0B;
  --font-heading: 'Clash Display', sans-serif;
  --font-body: 'Inter', sans-serif;
}
```

## 🛠 Tailwind Configuration

The theme system integrates with Tailwind CSS through CSS variables:

```js
// tailwind.config.js
colors: {
  'primary': 'var(--color-primary)',
  'accent': 'var(--color-accent)',
  'bg': {
    primary: 'var(--color-bg-primary)',
    secondary: 'var(--color-bg-secondary)',
  }
}
```

## 📱 Component Examples

### Themed Button
```tsx
<Button variant="primary">
  Primary Action
</Button>
```

### Themed Card
```tsx
<Card variant="campaign">
  <h3>Featured Campaign</h3>
  <p>Campaign description...</p>
</Card>
```

### Navigation with Theme Toggle
```tsx
<Header>
  <Logo />
  <Navigation />
  <ThemeToggle />
</Header>
```

## 🎨 Design System

### Color Tokens
- `primary`: Main brand color (changes per theme)
- `accent`: Secondary brand color
- `accent-secondary`: Tertiary accent color
- `bg-primary/secondary/tertiary`: Background variations
- `text-primary/secondary/tertiary`: Text color hierarchy

### Typography
- `font-head`: Heading font family (theme-dependent)
- `font-body`: Body text font family

### Spacing & Effects
- `radius-sm/md/lg/xl`: Border radius tokens
- `shadow-neon-sm/md/lg`: Glow effect variations
- `shadow-glass`: Glass morphism effect

## 🔧 Customization

### Adding New Themes
1. Define new CSS variables in `src/index.css`
2. Update the `ThemeToggle` component
3. Add theme-specific assets if needed

### Creating Theme-Aware Components
```tsx
// Use CSS variables in your components
const MyComponent = () => (
  <div className="bg-bg-primary text-text-primary border-primary">
    <h2 className="font-head text-primary">Themed Content</h2>
  </div>
)
```

## 📦 Project Structure

```
src/
├── components/
│   ├── ui/
│   │   ├── ThemeToggle.tsx     # Theme switching component
│   │   ├── Button.tsx          # Themed button variants
│   │   ├── Card.tsx           # Themed card variants
│   │   └── ...
│   └── demo/
│       └── ThemeShowcase.tsx   # Complete theme demo
├── pages/
│   └── UIKit.tsx              # Original UI kit
└── index.css                  # CSS variables & theme definitions
```

## 🎯 Routes

- `/` - Home dashboard
- `/ui-kit` - Original UI component library
- `/theme-showcase` - Complete theme demonstration
- `/brand-book` - Brand guidelines
- Other platform pages...

## 🌟 Key Features

- **Seamless Theme Switching**: Instant theme changes with smooth transitions
- **Component Consistency**: All components work across both themes
- **Developer Friendly**: Easy to extend and customize
- **Performance Optimized**: CSS variables for efficient theme switching
- **Accessibility**: Maintains contrast ratios across themes
- **Mobile Responsive**: Themes work perfectly on all devices

## 🎨 Figma Integration

The theme system is designed to work with Figma design tokens:
- Export design tokens as CSS variables
- Maintain design-development consistency
- Easy handoff between designers and developers

---

Built with ❤️ using React, TypeScript, Tailwind CSS, and modern web technologies.
