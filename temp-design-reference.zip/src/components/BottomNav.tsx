import React from 'react'
import { Home, Calendar, Trophy, MessageSquare, User } from 'lucide-react'
import { useNavigation } from './Layout'

interface BottomNavProps {
  onNavigate: (page: string) => void
  currentPage: string
}

const BottomNav: React.FC<BottomNavProps> = ({ onNavigate, currentPage }) => {
  const navItems = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'launch-calendar', icon: Calendar, label: 'Calendar' },
    { id: 'rewards', icon: Trophy, label: 'Rewards' },
    { id: 'raid-chat', icon: MessageSquare, label: 'Chat' },
    { id: 'profile', icon: User, label: 'Profile' },
  ]

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 lg:hidden z-30 px-4 py-2"
      style={{
        backgroundColor: 'rgba(11, 12, 14, 0.95)',
        backdropFilter: 'blur(12px)',
        borderTop: '1px solid rgba(255, 255, 255, 0.1)'
      }}
    >
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = currentPage === item.id
          
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-all duration-300"
              style={{
                color: isActive ? '#3CFF88' : '#6B7280'
              }}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}

export default BottomNav
