import React, { useState, createContext, useContext } from 'react'
import Header from './Header'
import Sidebar from './Sidebar'
import FloatingActionButton from './FloatingActionButton'
import BottomNav from './BottomNav'

interface LayoutProps {
  children: React.ReactNode
}

interface NavigationContextType {
  currentPage: string
  setCurrentPage: (page: string) => void
}

const NavigationContext = createContext<NavigationContextType | undefined>(undefined)

export const useNavigation = () => {
  const context = useContext(NavigationContext)
  if (!context) {
    throw new Error('useNavigation must be used within NavigationProvider')
  }
  return context
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [currentPage, setCurrentPage] = useState('home')

  const handleNavigate = (page: string) => {
    setCurrentPage(page)
    setSidebarOpen(false)
  }

  return (
    <NavigationContext.Provider value={{ currentPage, setCurrentPage: handleNavigate }}>
      <div className="min-h-screen" style={{ backgroundColor: '#0B0C0E', color: '#ffffff' }}>
        <Header 
          onMenuClick={() => setSidebarOpen(!sidebarOpen)} 
          onNavigate={handleNavigate}
        />
        
        <div className="flex">
          <Sidebar 
            isOpen={sidebarOpen} 
            onClose={() => setSidebarOpen(false)}
          />
          
          <main className="flex-1 lg:ml-64 pt-16 pb-20 lg:pb-8">
            <div style={{ animation: 'fadeIn 0.3s ease-out' }}>
              {children}
            </div>
          </main>
        </div>
        
        <FloatingActionButton />
        <BottomNav onNavigate={handleNavigate} currentPage={currentPage} />
      </div>
    </NavigationContext.Provider>
  )
}

export default Layout
