import React, { useState } from 'react'
import Layout from './components/Layout'
import Home from './pages/Home'
import LaunchCalendar from './pages/LaunchCalendar'
import Rewards from './pages/Rewards'
import RaidChat from './pages/RaidChat'
import Leaderboards from './pages/Leaderboards'
import Guide from './pages/Guide'
import Profile from './pages/Profile'
import BrandBook from './pages/BrandBook'
import UIKit from './pages/UIKit'
import MediaPack from './pages/MediaPack'
import UIKitFontVariations from './pages/UIKitFontVariations'
import MagicBentoDemo from './pages/MagicBentoDemo'

function App() {
  const [currentPage, setCurrentPage] = useState('home')

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home />
      case 'launch-calendar':
        return <LaunchCalendar />
      case 'rewards':
        return <Rewards />
      case 'raid-chat':
        return <RaidChat />
      case 'leaderboards':
        return <Leaderboards />
      case 'guide':
        return <Guide />
      case 'profile':
        return <Profile />
      case 'brand-book':
        return <BrandBook />
      case 'ui-kit':
        return <UIKit />
      case 'media-pack':
        return <MediaPack />
      case 'font-variations':
        return <UIKitFontVariations />
      case 'magic-bento':
        return <MagicBentoDemo />
      default:
        return <Home />
    }
  }

  return (
    <Layout>
      <div style={{ minHeight: '100vh' }}>
        {renderPage()}
      </div>
    </Layout>
  )
}

export default App
